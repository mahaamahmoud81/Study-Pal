<?php
session_start();

if (!isset($_SESSION["isLoggedIn"])) {
    header("Location: login.html");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>

<h2>Welcome, <?php echo htmlspecialchars($_SESSION["full_name"]); ?>!</h2>
<p>Your role: <?php echo htmlspecialchars($_SESSION["role"]); ?></p>

<p><a href="/studypal/logout.php">Logout</a></p>

</body>
</html>
