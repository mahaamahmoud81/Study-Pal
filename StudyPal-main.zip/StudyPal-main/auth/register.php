<?php
session_start();
require_once "../includes/db_connect.php";
require_once "../includes/functions.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("Invalid request method.");
}

$full_name = trim($_POST["full_name"] ?? "");
$dob       = $_POST["dob"] ?? "";
$email     = strtolower(trim($_POST["email"] ?? ""));
$password  = $_POST["password"] ?? "";
$role      = $_POST["role"] ?? "student";

if (!$full_name || !$dob || !$email || !$password) {
    die("Please fill out all fields.");
}

if (!validate_email($email)) {
    die("Invalid email format.");
}

// check if email exists
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$email]);

if ($stmt->fetch()) {
    die("Email already registered.");
}

$age = calculate_age($dob);

$password_hash = password_hash($password, PASSWORD_DEFAULT);

// insert user
$insert = $pdo->prepare("
    INSERT INTO users (full_name, dob, email, password, role)
    VALUES (?, ?, ?, ?, ?)
");
$insert->execute([$full_name, $dob, $email, $password_hash, $role]);

// redirect to login page
header("Location: ../login.html");
exit;
?>
