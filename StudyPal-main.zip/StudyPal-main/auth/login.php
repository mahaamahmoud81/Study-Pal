<?php
session_start();
require_once "../includes/db_connect.php";
require_once "../includes/functions.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("Invalid request method.");
}

$email = strtolower(trim($_POST["email"] ?? ""));
$password = $_POST["password"] ?? "";

if (!$email || !$password) {
    die("Please enter email and password.");
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user["password"])) {
    die("Incorrect email or password.");
}

session_regenerate_id(true); 

// successful login
$_SESSION["isLoggedIn"] = true;
$_SESSION["user_id"]    = $user["id"];
$_SESSION["full_name"]  = $user["full_name"];
$_SESSION["role"]       = $user["role"];

header("Location: ../dashboard.php");
exit;
?>

?>
