# StudyPal Backend API Documentation

This document describes all backend API endpoints built for the StudyPal platform.

---

## 1. Authentication Endpoints

### POST /auth/register.php
Registers a new user.

**Fields:**
- full_name
- dob
- email
- password
- role (student/tutor/parent)

**Response:**  
User created, or parent verification required (if student < 18).

---

### POST /auth/login.php
Logs a user in and creates a PHP session.

**Fields:**
- email
- password

**Response:**  
Session created, user data returned.

---

### GET /auth/logout.php
Destroys session and logs user out.

---

## 2. Courses

### POST /api/course_create.php  *(tutor/admin)*
Creates a course.

**Fields:**  
- title  
- description  

---

### GET /api/course_list.php
Returns all courses.

---

## 3. Enrolment

### POST /api/enroll_request.php  *(student)*
Request enrolment into a course.

**Fields:**  
- course_id  

---

### POST /api/enroll_approve.php  *(tutor/admin)*
Approve or reject enrolment.

**Fields:**  
- enrollment_id  
- action = approve | reject  

---

## 4. Parent Link

### POST /api/parent_link.php  *(parent)*
Links a parent to a student account.

**Fields:**  
- child_email  

---

## 5. Resources

### POST /api/upload_resource.php  *(tutor)*
Uploads a resource file.

**Fields:**
- course_id
- file
- available_from
- available_until

---

### GET /api/resource_list.php?course_id=ID
Lists resources for a course with role-based restrictions.

---

### GET /api/resource_download.php?id=ID
Downloads a file and logs the download in `resource_downloads`.

---

## 6. Progress Tracking

### POST /api/progress_update.php  *(tutor)*
Updates student progress.

**Fields:**  
- student_id  
- course_id  
- progress (0–100)

---

### GET /api/progress_get.php
Role-based progress overview.

---

## 7. Messaging

### POST /api/messages_send.php
Sends a message to another user.

**Fields:**  
- receiver_id  
- message  

---

### GET /api/messages_list.php
Lists messages between logged-in user and others.

---

## 8. Quizzes

### POST /api/quiz_create.php  *(tutor)*
Creates a quiz.

**Fields:**  
- course_id  
- title  
- allow_retake (0 or 1)

---

### POST /api/quiz_add_question.php  *(tutor)*
Adds questions to quiz.

**Fields:**  
- quiz_id  
- question  
- correct_answer  

---

### GET /api/quiz_list.php
Lists quizzes based on role.

---

### POST /api/quiz_submit.php  *(student)*
Submits quiz answers.  

Includes retake protection.

**Fields:**  
- quiz_id  
- answers[]  

---

### GET /api/quiz_results.php?quiz_id=ID  *(tutor/admin)*
Returns student quiz results.

---

## 9. Dashboards

### GET /api/dashboard_student.php
Courses, progress, and resources.

---

### GET /api/dashboard_tutor.php
Courses, pending enrolments, approved students.

---

### GET /api/dashboard_parent.php
Child info, courses, progress.

---

### GET /api/admin_users_list.php  *(admin)*
Lists all users.

---

# End of API Documentation
