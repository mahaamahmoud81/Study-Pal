<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    json_response(["error" => "Unauthorized"], 401);
}

function require_role($roles) {
    if (!is_array($roles)) $roles = [$roles];

    if (!in_array($_SESSION["role"], $roles)) {
        json_response(["error" => "Forbidden"], 403);
    }
}
?>
