<?php
function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function calculate_age($dob) {
    if (!$dob) return null;
    $dobObj = new DateTime($dob);
    $now = new DateTime();
    return $dobObj->diff($now)->y;
}

function json_response($data, $status = 200) {
    http_response_code($status);
    header("Content-Type: application/json; charset=utf-8");
    echo json_encode($data);
    exit;
}
?>
