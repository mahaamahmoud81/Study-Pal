<?php
require_once __DIR__ . "/../includes/db_connect.php";
require_once __DIR__ . "/../includes/functions.php";
session_start();

if (!isset($_SESSION['isLoggedIn']) || !in_array($_SESSION['role'], ['tutor','admin'])) json_response(['error'=>'Unauthorized'],401);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_response(['error'=>'POST required'],405);

$enrollment_id = (int)($_POST['enrollment_id'] ?? 0);
$action = $_POST['action'] ?? 'approve'; // approve or reject

if (!$enrollment_id) json_response(['error'=>'enrollment_id required'],400);

$st = $pdo->prepare("SELECT e.*, c.tutor_id FROM enrollments e JOIN courses c ON e.course_id=c.id WHERE e.id=?");
$st->execute([$enrollment_id]);
$row = $st->fetch();
if (!$row) json_response(['error'=>'Enrollment not found'],404);

// if tutor, must be tutor of course (unless admin)
if ($_SESSION['role'] === 'tutor' && $_SESSION['user_id'] != $row['tutor_id']) json_response(['error'=>'Forbidden'],403);

$status = ($action === 'reject') ? 'rejected' : 'approved';
$upd = $pdo->prepare("UPDATE enrollments SET status=? WHERE id=?");
$upd->execute([$status,$enrollment_id]);

json_response(['message'=>'Enrollment '.$status]);
