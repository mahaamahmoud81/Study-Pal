<?php
require_once __DIR__ . "/../includes/db_connect.php";
require_once __DIR__ . "/../includes/functions.php";
session_start();

if (!isset($_SESSION['isLoggedIn']) || $_SESSION['role']!=='admin') json_response(['error'=>'Unauthorized'],401);

$stmt = $pdo->query("SELECT id, full_name, email, role, created_at FROM users ORDER BY created_at DESC");
json_response(['users'=>$stmt->fetchAll()]);
