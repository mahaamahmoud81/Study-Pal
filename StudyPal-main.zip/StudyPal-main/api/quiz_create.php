<?php
require_once __DIR__ . "/../includes/db_connect.php";
require_once __DIR__ . "/../includes/functions.php";
session_start();

if (!isset($_SESSION['isLoggedIn']) || $_SESSION['role'] !== 'tutor') {
    json_response(["error" => "Unauthorized"], 401);
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    json_response(["error" => "POST required"], 405);
}

$title = $_POST["title"] ?? "";
$course_id = (int)($_POST["course_id"] ?? 0);
$tutor_id = $_SESSION["user_id"];

if (!$title || !$course_id) {
    json_response(["error" => "Missing title or course_id"], 400);
}

// verify tutor owns the course
$check = $pdo->prepare("SELECT id FROM courses WHERE id=? AND tutor_id=?");
$check->execute([$course_id, $tutor_id]);

if (!$check->fetch()) {
    json_response(["error" => "Not your course"], 403);
}

$insert = $pdo->prepare("INSERT INTO quizzes (course_id, tutor_id, title) VALUES (?, ?, ?)");
$insert->execute([$course_id, $tutor_id, $title]);

json_response(["message" => "Quiz created", "quiz_id" => $pdo->lastInsertId()]);
?>
