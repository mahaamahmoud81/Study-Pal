<?php
require_once __DIR__ . "/../includes/db_connect.php";
session_start();

if (!isset($_SESSION['isLoggedIn'])) {
    http_response_code(401);
    echo "Unauthorized";
    exit;
}

$id = (int)($_GET['id'] ?? 0);
if (!$id) {
    http_response_code(400);
    echo "resource_id required";
    exit;
}

$stmt = $pdo->prepare("
    SELECT r.*, u.full_name AS uploaded_by_name 
    FROM resources r 
    JOIN users u ON r.uploaded_by = u.id
    WHERE r.id = ?
");
$stmt->execute([$id]);
$res = $stmt->fetch();

if (!$res) {
    http_response_code(404);
    echo "Resource not found";
    exit;
}

// Availability checks (if columns exist)
$now = date('Y-m-d H:i:s');

if (!empty($res['available_from']) && $now < $res['available_from']) {
    http_response_code(403);
    echo "Resource not yet available";
    exit;
}
if (!empty($res['available_until']) && $now > $res['available_until']) {
    http_response_code(403);
    echo "Resource expired";
    exit;
}

$file_path = __DIR__ . "/../" . $res['file_path'];

if (!file_exists($file_path)) {
    http_response_code(404);
    echo "File missing on server";
    exit;
}

$original_name = $res['file_name']; // Your DB column!!!

// Track download
$track = $pdo->prepare("INSERT INTO resource_downloads (resource_id, user_id) VALUES (?, ?)");
$track->execute([$id, $_SESSION['user_id']]);

// Force browser download
header("Content-Type: application/octet-stream");
header("Content-Disposition: attachment; filename=\"" . $original_name . "\"");
header("Content-Length: " . filesize($file_path));

readfile($file_path);
exit;
?>
