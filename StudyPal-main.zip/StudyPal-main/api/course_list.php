<?php
require_once __DIR__ . "/../includes/db_connect.php";
require_once __DIR__ . "/../includes/functions.php";

$stmt = $pdo->query("SELECT c.*, u.full_name AS tutor_name FROM courses c LEFT JOIN users u ON c.tutor_id=u.id ORDER BY c.created_at DESC");
$courses = $stmt->fetchAll();
json_response(['courses'=>$courses]);
