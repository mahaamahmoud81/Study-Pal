<?php
require_once __DIR__ . "/../includes/db_connect.php";
session_start();

if (!isset($_SESSION['isLoggedIn']) || $_SESSION['role'] !== 'tutor') {
    http_response_code(401);
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

$user_id = $_SESSION['user_id'];

$subjects = trim($_POST['subjects'] ?? "");
$level = trim($_POST['level'] ?? "");
$experience = (int)($_POST['experience'] ?? 0);
$description = trim($_POST['description'] ?? "");
$rate = (float)($_POST['rate'] ?? 0);

if (!$subjects || !$level || !$description) {
    http_response_code(400);
    echo json_encode(["error" => "Required fields missing"]);
    exit;
}

// Handle optional image upload
$profile_image_path = null;

if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === 0) {

    $allowed = ['image/jpeg', 'image/png', 'image/jpg'];
    $mime = mime_content_type($_FILES['profile_image']['tmp_name']);

    if (!in_array($mime, $allowed)) {
        echo json_encode(["error" => "Invalid image type"]);
        exit;
    }

    $ext = pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION);
    $safeName = "tutor_" . $user_id . "_" . bin2hex(random_bytes(4)) . "." . $ext;

    $uploadDir = __DIR__ . "/../uploads/profile_images/";
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $dest = $uploadDir . $safeName;

    if (!move_uploaded_file($_FILES['profile_image']['tmp_name'], $dest)) {
        echo json_encode(["error" => "Image upload failed"]);
        exit;
    }

    $profile_image_path = "uploads/profile_images/" . $safeName;
}

// Check if profile exists
$check = $pdo->prepare("SELECT user_id FROM tutor_profiles WHERE user_id=?");
$check->execute([$user_id]);
$exists = $check->fetch();

if ($exists) {
    // Update existing profile
    $sql = "
        UPDATE tutor_profiles
        SET subjects=?, level=?, experience_years=?, description=?, rate=?
    ";
    $params = [$subjects, $level, $experience, $description, $rate];

    if ($profile_image_path) {
        $sql .= ", profile_image=?";
        $params[] = $profile_image_path;
    }

    $sql .= " WHERE user_id=?";
    $params[] = $user_id;

    $q = $pdo->prepare($sql);
    $q->execute($params);

} else {
    // Create new profile
    $q = $pdo->prepare("
        INSERT INTO tutor_profiles (user_id, subjects, level, experience_years, description, rate, profile_image)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $q->execute([
        $user_id,
        $subjects,
        $level,
        $experience,
        $description,
        $rate,
        $profile_image_path
    ]);
}

echo json_encode(["message" => "Tutor profile saved"]);
exit;
