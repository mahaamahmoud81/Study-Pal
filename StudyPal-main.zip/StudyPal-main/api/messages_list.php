<?php
require_once __DIR__ . "/../includes/db_connect.php";
session_start();

if (!isset($_SESSION['isLoggedIn'])) {
    http_response_code(401);
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

$user_id = $_SESSION['user_id'];

$st = $pdo->prepare("
    SELECT m.id, m.message, m.sent_at,
           u.full_name AS sender_name,
           u2.full_name AS receiver_name
    FROM messages m
    JOIN users u ON m.sender_id = u.id
    JOIN users u2 ON m.receiver_id = u2.id
    WHERE m.sender_id = ? OR m.receiver_id = ?
    ORDER BY m.sent_at DESC
");
$st->execute([$user_id, $user_id]);

echo json_encode($st->fetchAll());
exit;
