<?php
require_once __DIR__ . "/../includes/db_connect.php";
require_once __DIR__ . "/../includes/functions.php";
session_start();

if (!isset($_SESSION["isLoggedIn"]) || !in_array($_SESSION["role"], ["tutor","admin"])) {
    json_response(["error" => "Unauthorized"], 401);
}

$quiz_id = (int)($_GET["quiz_id"] ?? 0);

if (!$quiz_id) json_response(["error" => "quiz_id required"], 400);

// tutors can only view their own quizzes
if ($_SESSION["role"] === "tutor") {
    $check = $pdo->prepare("SELECT tutor_id FROM quizzes WHERE id=?");
    $check->execute([$quiz_id]);
    $row = $check->fetch();

    if (!$row || $row["tutor_id"] != $_SESSION["user_id"]) {
        json_response(["error" => "Forbidden"], 403);
    }
}

$stmt = $pdo->prepare("
    SELECT qa.*, u.full_name
    FROM quiz_attempts qa
    JOIN users u ON qa.student_id = u.id
    WHERE qa.quiz_id = ?
");
$stmt->execute([$quiz_id]);

json_response(["results" => $stmt->fetchAll()]);
?>
