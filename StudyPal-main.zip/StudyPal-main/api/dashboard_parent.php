<?php
require_once __DIR__ . "/../includes/db_connect.php";
session_start();

if (!isset($_SESSION['isLoggedIn']) || $_SESSION['role'] !== 'parent') {
    http_response_code(401);
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

$parent_id = $_SESSION['user_id'];

// Check linked child
$child = $pdo->prepare("
    SELECT u.id, u.full_name, u.email
    FROM parent_child pc
    JOIN users u ON pc.child_id = u.id
    WHERE pc.parent_id = ?
");
$child->execute([$parent_id]);
$childData = $child->fetch();

if (!$childData) {
    echo json_encode(["message" => "No linked child"]);
    exit;
}

$child_id = $childData['id'];

// Child courses
$courses = $pdo->prepare("
    SELECT c.id, c.title
    FROM enrollments e
    JOIN courses c ON c.id = e.course_id
    WHERE e.user_id = ? AND e.status = 'approved'
");
$courses->execute([$child_id]);

// Child progress
$progress = $pdo->prepare("
    SELECT p.course_id, p.progress, c.title
    FROM progress p
    JOIN courses c ON c.id = p.course_id
    WHERE p.user_id = ?
");
$progress->execute([$child_id]);

echo json_encode([
    "child" => $childData,
    "courses" => $courses->fetchAll(),
    "progress" => $progress->fetchAll()
]);
exit;
