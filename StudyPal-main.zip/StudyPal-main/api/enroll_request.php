<?php
require_once __DIR__ . "/../includes/db_connect.php";
require_once __DIR__ . "/../includes/functions.php";
session_start();

if (!isset($_SESSION['isLoggedIn']) || $_SESSION['role'] !== 'student') json_response(['error'=>'Unauthorized'],401);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_response(['error'=>'POST required'],405);

$course_id = (int)($_POST['course_id'] ?? 0);
if (!$course_id) json_response(['error'=>'course_id required'],400);

// check duplicate
$check = $pdo->prepare("SELECT id FROM enrollments WHERE user_id=? AND course_id=?");
$check->execute([$_SESSION['user_id'],$course_id]);
if ($check->fetch()) json_response(['error'=>'Already requested or enrolled'],409);

$ins = $pdo->prepare("INSERT INTO enrollments (user_id, course_id, status) VALUES (?, ?, 'pending')");
$ins->execute([$_SESSION['user_id'],$course_id]);
json_response(['message'=>'Enrollment requested'],201);
