<?php
require_once __DIR__ . "/../includes/db_connect.php";
session_start();

if (!isset($_SESSION['isLoggedIn']) || $_SESSION['role'] !== 'student') {
    http_response_code(401);
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

$student_id = $_SESSION['user_id'];

// Get approved courses
$courses = $pdo->prepare("
    SELECT c.id, c.title, c.description
    FROM enrollments e
    JOIN courses c ON e.course_id = c.id
    WHERE e.user_id = ? AND e.status = 'approved'
");
$courses->execute([$student_id]);

// Progress
$progress = $pdo->prepare("
    SELECT p.course_id, p.progress, c.title
    FROM progress p
    JOIN courses c ON p.course_id = c.id
    WHERE p.user_id = ?
");
$progress->execute([$student_id]);

// Recent resources
$resources = $pdo->prepare("
    SELECT r.id, r.file_name, r.uploaded_at, c.title AS course
    FROM resources r
    JOIN courses c ON r.course_id = c.id
    WHERE r.course_id IN (
        SELECT course_id FROM enrollments WHERE user_id=? AND status='approved'
    )
    ORDER BY r.uploaded_at DESC LIMIT 5
");
$resources->execute([$student_id]);

// Recent messages
$messages = $pdo->prepare("
    SELECT m.message, m.sent_at, u.full_name AS sender
    FROM messages m
    JOIN users u ON m.sender_id = u.id
    WHERE m.receiver_id = ?
    ORDER BY m.sent_at DESC LIMIT 5
");
$messages->execute([$student_id]);

echo json_encode([
    "courses" => $courses->fetchAll(),
    "progress" => $progress->fetchAll(),
    "resources" => $resources->fetchAll(),
    "messages" => $messages->fetchAll()
]);
exit;
