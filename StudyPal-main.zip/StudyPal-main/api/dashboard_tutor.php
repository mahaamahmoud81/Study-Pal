<?php
require_once __DIR__ . "/../includes/db_connect.php";
session_start();

if (!isset($_SESSION['isLoggedIn']) || $_SESSION['role'] !== 'tutor') {
    http_response_code(401);
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

$tutor_id = $_SESSION['user_id'];

// Courses owned by tutor
$courses = $pdo->prepare("
    SELECT id, title, description
    FROM courses
    WHERE tutor_id = ?
");
$courses->execute([$tutor_id]);

// Pending enrollment requests
$pending = $pdo->prepare("
    SELECT e.id AS enrollment_id, u.full_name, c.title
    FROM enrollments e
    JOIN users u ON e.user_id = u.id
    JOIN courses c ON e.course_id = c.id
    WHERE c.tutor_id = ? AND e.status = 'pending'
");
$pending->execute([$tutor_id]);

// Approved students
$students = $pdo->prepare("
    SELECT u.full_name, c.title
    FROM enrollments e
    JOIN users u ON u.id = e.user_id
    JOIN courses c ON c.id = e.course_id
    WHERE c.tutor_id = ? AND e.status = 'approved'
");
$students->execute([$tutor_id]);

echo json_encode([
    "courses" => $courses->fetchAll(),
    "pending_requests" => $pending->fetchAll(),
    "approved_students" => $students->fetchAll()
]);
exit;
