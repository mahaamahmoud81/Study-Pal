<?php
require_once __DIR__ . "/../includes/db_connect.php";
session_start();

if (!isset($_SESSION['isLoggedIn'])) {
    http_response_code(401);
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

if ($role === 'student') {

    // Students see ONLY their own progress
    $q = $pdo->prepare("
        SELECT p.progress, p.updated_at, c.id AS course_id, c.title
        FROM progress p
        JOIN courses c ON p.course_id = c.id
        WHERE p.user_id = ?
    ");
    $q->execute([$user_id]);
    echo json_encode($q->fetchAll());
    exit;

}

if ($role === 'tutor') {

    // Tutors see only progress for their own students
    $q = $pdo->prepare("
        SELECT p.progress, p.updated_at, c.title, u.full_name AS student
        FROM progress p
        JOIN courses c ON p.course_id = c.id
        JOIN users u ON p.user_id = u.id
        WHERE c.tutor_id = ?
    ");
    $q->execute([$user_id]);
    echo json_encode($q->fetchAll());
    exit;

}

// Admin sees everything
$q = $pdo->query("
    SELECT p.progress, p.updated_at, c.title, u.full_name AS student
    FROM progress p
    JOIN courses c ON p.course_id = c.id
    JOIN users u ON p.user_id = u.id
");
echo json_encode($q->fetchAll());
exit;
