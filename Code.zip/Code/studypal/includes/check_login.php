<?php
session_start();

if (!isset($_SESSION['isLoggedIn'])) {
    http_response_code(401);
    echo json_encode(["error" => "Not logged in"]);
    exit;
}

echo json_encode([
    "user_id" => $_SESSION["user_id"],
    "full_name" => $_SESSION["full_name"],
    "role" => $_SESSION["role"]
]);
