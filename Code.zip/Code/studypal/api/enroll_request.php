<?php
// /studypal/api/enroll_request.php
session_start();

require_once __DIR__ . "/../includes/db_connect.php";
require_once __DIR__ . "/../includes/functions.php";

if (!isset($_SESSION["isLoggedIn"]) || $_SESSION["isLoggedIn"] !== true) {
    json_response(["error" => "Unauthorized"], 401);
}

if (($_SESSION["role"] ?? "") !== "student") {
    json_response(["error" => "Only students can enroll"], 403);
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    json_response(["error" => "POST required"], 405);
}

$course_id = (int)($_POST["course_id"] ?? 0);
if ($course_id <= 0) {
    json_response(["error" => "course_id required"], 400);
}

// Ensure course exists
$c = $pdo->prepare("SELECT id FROM courses WHERE id = ?");
$c->execute([$course_id]);
if (!$c->fetch()) {
    json_response(["error" => "Course not found"], 404);
}

// Prevent duplicates
$check = $pdo->prepare("SELECT id, status FROM enrollments WHERE user_id = ? AND course_id = ? LIMIT 1");
$check->execute([(int)$_SESSION["user_id"], $course_id]);
$existing = $check->fetch(PDO::FETCH_ASSOC);

if ($existing) {
    json_response(["error" => "Already requested/enrolled (" . ($existing["status"] ?? "unknown") . ")"], 409);
}

// Insert pending request
$ins = $pdo->prepare("INSERT INTO enrollments (user_id, course_id, status) VALUES (?, ?, 'pending')");
$ins->execute([(int)$_SESSION["user_id"], $course_id]);

json_response(["message" => "Enrollment request sent", "course_id" => $course_id], 201);
