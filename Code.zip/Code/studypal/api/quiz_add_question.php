<?php
require_once __DIR__ . "/../includes/db_connect.php";
session_start();

if (!isset($_SESSION['isLoggedIn']) || $_SESSION['role'] !== 'tutor') {
    http_response_code(401);
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

$quiz_id = (int)($_POST['quiz_id'] ?? 0);
$question = trim($_POST['question'] ?? "");
$option_a = trim($_POST['option_a'] ?? "");
$option_b = trim($_POST['option_b'] ?? "");
$option_c = trim($_POST['option_c'] ?? "");
$option_d = trim($_POST['option_d'] ?? "");
$correct = strtoupper(trim($_POST['correct_answer'] ?? ""));

if (!$quiz_id || !$question || !$option_a || !$option_b || !$option_c || !$option_d) {
    http_response_code(400);
    echo json_encode(["error" => "All fields required"]);
    exit;
}

if (!in_array($correct, ['A','B','C','D'])) {
    http_response_code(400);
    echo json_encode(["error" => "correct_answer must be A, B, C, or D"]);
    exit;
}

$q = $pdo->prepare("INSERT INTO quiz_questions (quiz_id, question, option_a, option_b, option_c, option_d, correct_answer)
                    VALUES (?, ?, ?, ?, ?, ?, ?)");
$q->execute([$quiz_id, $question, $option_a, $option_b, $option_c, $option_d, $correct]);

echo json_encode(["message" => "Question added"]);
