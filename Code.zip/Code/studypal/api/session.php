<?php
// /studypal/api/session.php
session_start();
header("Content-Type: application/json; charset=utf-8");

echo json_encode([
    "isLoggedIn" => (bool)($_SESSION["isLoggedIn"] ?? false),
    "user_id"    => (int)($_SESSION["user_id"] ?? 0),
    "role"       => (string)($_SESSION["role"] ?? ""),
    "full_name"  => (string)($_SESSION["full_name"] ?? ""),
], JSON_UNESCAPED_UNICODE);
