<?php
require_once __DIR__ . "/../includes/db_connect.php";
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'parent') {
    http_response_code(401);
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

$parent_id = $_SESSION['user_id'];

/* Get linked child */
$stmt = $pdo->prepare("
    SELECT u.id, u.full_name
    FROM parent_child pc
    JOIN users u ON pc.child_id = u.id
    WHERE pc.parent_id = ?
");
$stmt->execute([$parent_id]);
$child = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$child) {
    echo json_encode(["error" => "No linked child"]);
    exit;
}

$child_id = $child['id'];

/* Quiz analytics */
$quizStats = $pdo->prepare("
    SELECT q.title,
           qr.score,
           qr.total,
           qr.created_at
    FROM quiz_results qr
    JOIN quizzes q ON q.id = qr.quiz_id
    WHERE qr.student_id = ?
");
$quizStats->execute([$child_id]);

/* Course list */
$courses = $pdo->prepare("
    SELECT c.title
    FROM enrollments e
    JOIN courses c ON c.id = e.course_id
    WHERE e.student_id = ? AND e.status = 'approved'
");
$courses->execute([$child_id]);

echo json_encode([
    "child" => $child,
    "courses" => $courses->fetchAll(PDO::FETCH_COLUMN),
    "quizzes" => $quizStats->fetchAll(PDO::FETCH_ASSOC)
]);
