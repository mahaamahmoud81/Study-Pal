<?php
require_once __DIR__ . "/../includes/db_connect.php";
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'parent') {
    http_response_code(401);
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

$parent_id = $_SESSION['user_id'];

/**
 * Parent info
 */
$parentStmt = $pdo->prepare("
    SELECT id, full_name
    FROM users
    WHERE id = ?
");
$parentStmt->execute([$parent_id]);
$parent = $parentStmt->fetch(PDO::FETCH_ASSOC);

if (!$parent) {
    echo json_encode(["error" => "Parent not found"]);
    exit;
}

/**
 * Linked children
 */
$childrenStmt = $pdo->prepare("
    SELECT u.id, u.full_name
    FROM parent_child pc
    JOIN users u ON pc.student_id = u.id
    WHERE pc.parent_id = ?
");
$childrenStmt->execute([$parent_id]);
$children = $childrenStmt->fetchAll(PDO::FETCH_ASSOC);

/**
 * Active courses for those children
 */
$courseCount = 0;
if ($children) {
    $childIds = array_column($children, 'id');
    $placeholders = implode(',', array_fill(0, count($childIds), '?'));

    $courseStmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM enrollments
        WHERE user_id IN ($placeholders)
          AND status = 'approved'
    ");
    $courseStmt->execute($childIds);
    $courseCount = (int)$courseStmt->fetchColumn();
}

echo json_encode([
    "parent_name" => $parent['full_name'],
    "children_count" => count($children),
    "children" => $children,
    "active_courses" => $courseCount
]);
