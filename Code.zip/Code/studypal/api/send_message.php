<?php
require_once __DIR__ . "/../includes/db_connect.php";
session_start();

if (!isset($_SESSION['isLoggedIn'])) {
    http_response_code(401);
    exit("Unauthorized");
}

$sender_id   = $_SESSION['user_id'];
$receiver_id = (int)($_POST['receiver_id'] ?? 0);
$message     = trim($_POST['message'] ?? '');

if (!$receiver_id || $message === '') {
    http_response_code(400);
    exit("Invalid input");
}

$stmt = $pdo->prepare("
    INSERT INTO messages (sender_id, receiver_id, message)
    VALUES (?, ?, ?)
");

$stmt->execute([$sender_id, $receiver_id, $message]);

echo "OK";
