<?php
require_once __DIR__ . "/../includes/db_connect.php";
session_start();

// must be logged in
if (!isset($_SESSION['isLoggedIn'])) {
    http_response_code(401);
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

$sender_id = $_SESSION['user_id'];
$receiver_id = (int)($_POST['receiver_id'] ?? 0);
$body = trim($_POST['body'] ?? "");

// validate receiver
if (!$receiver_id) {
    http_response_code(400);
    echo json_encode(["error" => "receiver_id required"]);
    exit;
}

// validate message body
if ($body === "") {
    http_response_code(400);
    echo json_encode(["error" => "Message body required"]);
    exit;
}

// check receiver exists
$chk = $pdo->prepare("SELECT id FROM users WHERE id = ?");
$chk->execute([$receiver_id]);
if (!$chk->fetch()) {
    http_response_code(404);
    echo json_encode(["error" => "Receiver not found"]);
    exit;
}

// insert message (column name is 'message')
$insert = $pdo->prepare("
    INSERT INTO messages (sender_id, receiver_id, message)
    VALUES (?, ?, ?)
");
$insert->execute([$sender_id, $receiver_id, $body]);

echo json_encode(["message" => "sent"]);
exit;
