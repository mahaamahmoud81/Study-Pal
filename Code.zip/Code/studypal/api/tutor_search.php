<?php
require_once __DIR__ . "/../includes/db_connect.php";
session_start();

// anyone can use search, logged in or not

$subject = strtolower(trim($_GET['subject'] ?? ""));

if (!$subject) {
    http_response_code(400);
    echo json_encode(["error" => "subject required"]);
    exit;
}

// find tutors whose subject list contains this keyword
$q = $pdo->prepare("
    SELECT u.id, u.full_name, tp.subjects, tp.experience_years, tp.description, tp.rate
    FROM users u
    JOIN tutor_profiles tp ON u.id = tp.user_id
    WHERE u.role='tutor'
      AND LOWER(tp.subjects) LIKE ?
");
$q->execute(['%' . $subject . '%']);

echo json_encode($q->fetchAll());
exit;
