<?php
session_start();

if (!isset($_SESSION['isLoggedIn'])) {
    http_response_code(401);
    exit("Unauthorized");
}

$files = [
    1 => "calculus_derivatives_worksheet.txt",
    2 => "physics_kinematics_notes.txt",
    3 => "python_programming_exercises.txt"
];

$id = (int)($_GET['id'] ?? 0);

if (!isset($files[$id])) {
    http_response_code(404);
    exit("File not found");
}

$filePath = __DIR__ . "/../uploads/" . $files[$id];

if (!file_exists($filePath)) {
    http_response_code(404);
    exit("Missing file on server");
}

header("Content-Type: application/octet-stream");
header("Content-Disposition: attachment; filename=\"" . basename($filePath) . "\"");
header("Content-Length: " . filesize($filePath));

readfile($filePath);
exit;
