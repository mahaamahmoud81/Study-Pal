<?php
require_once __DIR__ . "/../includes/db_connect.php";
require_once __DIR__ . "/../includes/functions.php";
session_start();

if (!isset($_SESSION['isLoggedIn']) || $_SESSION['role'] !== 'parent') json_response(['error'=>'Unauthorized'],401);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_response(['error'=>'POST required'],405);

$child_email = strtolower(trim($_POST['child_email'] ?? ''));
if (!$child_email) json_response(['error'=>'child_email required'],400);

$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND role = 'student'");
$stmt->execute([$child_email]);
$child = $stmt->fetch();
if (!$child) json_response(['error'=>'Child not found'],404);

$ins = $pdo->prepare("INSERT IGNORE INTO parent_child (parent_id, child_id) VALUES (?, ?)");
$ins->execute([$_SESSION['user_id'], $child['id']]);

json_response(['message'=>'Parent linked to child']);
