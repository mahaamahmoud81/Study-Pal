<?php
require_once __DIR__ . "/../includes/db_connect.php";
header("Content-Type: application/json");

$subject = $_GET["subject"] ?? "";

// If subject filter exists
if ($subject) {
    $sql = "
        SELECT 
            c.id AS course_id,
            c.title AS course_title,
            c.description AS course_description,
            c.level AS course_level,
            c.subject AS course_subject,
            u.id AS tutor_id,
            u.full_name AS tutor_name,
            tp.experience_years,
            tp.rate,
            tp.profile_image
        FROM courses c
        JOIN users u ON c.tutor_id = u.id
        LEFT JOIN tutor_profiles tp ON tp.user_id = u.id
        WHERE c.subject = ?
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$subject]);
} else {
    // No filter → return all courses
    $sql = "
        SELECT 
            c.id AS course_id,
            c.title AS course_title,
            c.description AS course_description,
            c.level AS course_level,
            c.subject AS course_subject,
            u.id AS tutor_id,
            u.full_name AS tutor_name,
            tp.experience_years,
            tp.rate,
            tp.profile_image
        FROM courses c
        JOIN users u ON c.tutor_id = u.id
        LEFT JOIN tutor_profiles tp ON tp.user_id = u.id
    ";
    $stmt = $pdo->query($sql);
}

$data = $stmt->fetchAll();

echo json_encode(["courses" => $data]);
