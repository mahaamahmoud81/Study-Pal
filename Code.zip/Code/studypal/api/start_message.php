<?php
session_start();
require_once "../includes/db_connect.php";

$sender = $_SESSION["user_id"];
$receiver = $_POST["receiver_id"];

$stmt = $pdo->prepare("
    INSERT INTO messages (sender_id, receiver_id, message)
    VALUES (?, ?, 'Hello')
");
$stmt->execute([$sender, $receiver]);

header("Location: /studypal/frontend/student_messages.php");
exit;
