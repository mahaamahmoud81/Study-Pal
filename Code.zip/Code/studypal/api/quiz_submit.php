<?php
require_once __DIR__ . "/../includes/db_connect.php";
session_start();

if (!isset($_SESSION['isLoggedIn']) || $_SESSION['role'] !== 'student') {
    http_response_code(401);
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

$quiz_id = (int)($_POST['quiz_id'] ?? 0);
$answers_raw = trim($_POST['answers'] ?? "");

if (!$quiz_id || !$answers_raw) {
    http_response_code(400);
    echo json_encode(["error" => "quiz_id and answers required"]);
    exit;
}

$answers = [];
foreach (explode("\n", $answers_raw) as $line) {
    if (strpos($line, "=") !== false) {
        list($qid, $ans) = explode("=", $line);
        $answers[(int)$qid] = strtoupper(trim($ans));
    }
}

// Prevent retake
$chk = $pdo->prepare("SELECT id FROM quiz_attempts WHERE quiz_id=? AND student_id=?");
$chk->execute([$quiz_id, $_SESSION['user_id']]);
$attempt = $chk->fetch();
if ($attempt) {
    http_response_code(409);
    echo json_encode(["error" => "Already completed"]);
    exit;
}

// Get questions
$q = $pdo->prepare("SELECT id, correct_answer FROM quiz_questions WHERE quiz_id=?");
$q->execute([$quiz_id]);
$questions = $q->fetchAll();

$score = 0;
$total = count($questions);

foreach ($questions as $ques) {
    $qid = $ques['id'];
    if (isset($answers[$qid]) && $answers[$qid] === $ques['correct_answer']) {
        $score++;
    }
}

$save = $pdo->prepare("INSERT INTO quiz_attempts (quiz_id, student_id, score)
                       VALUES (?, ?, ?)");
$save->execute([$quiz_id, $_SESSION['user_id'], $score]);

echo json_encode(["message" => "Quiz submitted", "score" => $score, "total" => $total]);
