<?php
require_once __DIR__ . "/../includes/db_connect.php";
require_once __DIR__ . "/../includes/functions.php";

// must be POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(["error" => "POST required"], 405);
}

$forename = trim($_POST['forename'] ?? '');
$surname = trim($_POST['surname'] ?? '');
$email = strtolower(trim($_POST['email'] ?? ''));
$dob = $_POST['dob'] ?? '';
$qualifications = trim($_POST['qualifications'] ?? '');
$last_degree = trim($_POST['last_degree'] ?? '');
$subjects = trim($_POST['subjects'] ?? '');
$teach_level = $_POST['teach_level'] ?? '';
$pay_rate = $_POST['pay_rate'] ?? 0;

// validate
if (!$forename || !$surname || !$email || !$qualifications) {
    json_response(["error" => "Missing required fields"], 400);
}

// save profile image
$profile_image = null;
if (!empty($_FILES['profile_image']['name'])) {
    $ext = pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION);
    $newName = bin2hex(random_bytes(5)) . "." . $ext;
    $uploadPath = __DIR__ . "/../uploads/profile_images/" . $newName;

    if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $uploadPath)) {
        $profile_image = "uploads/profile_images/" . $newName;
    }
}

// insert into tutor_applications
$stmt = $pdo->prepare("
    INSERT INTO tutor_applications 
    (forename, surname, email, dob, qualifications, last_degree, subjects, teach_level, pay_rate, profile_image)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");
$stmt->execute([
    $forename, $surname, $email, $dob, 
    $qualifications, $last_degree, $subjects, 
    $teach_level, $pay_rate, $profile_image
]);

json_response(["message" => "Application submitted"], 201);
