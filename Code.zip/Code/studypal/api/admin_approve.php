<?php
session_start();
require_once "../includes/db_connect.php";

// only admin can approve
if (!isset($_SESSION["isLoggedIn"]) || $_SESSION["role"] !== "admin") {
    die("Unauthorized.");
}

$id = (int)($_POST["id"] ?? 0);
$action = $_POST["action"] ?? "";

if (!$id || !in_array($action, ["approve", "reject"])) {
    die("Invalid request.");
}

$status = ($action === "approve") ? 1 : -1;

$stmt = $pdo->prepare("UPDATE users SET approved = ? WHERE id = ?");
$stmt->execute([$status, $id]);

header("Location: ../admin_dashboard.php");
exit;
?>
