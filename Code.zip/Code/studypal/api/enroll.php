<?php
require_once "../includes/db_connect.php";
require_once "../includes/functions.php";
require_once "../includes/check_login.php";

$course_id = $_POST["course_id"] ?? 0;
$user_id = $_SESSION["user_id"];

// check duplicate
$stmt = $pdo->prepare("SELECT id FROM enrollments WHERE user_id = ? AND course_id = ?");
$stmt->execute([$user_id, $course_id]);

if ($stmt->fetch()) {
    json_response(["error" => "Already enrolled or pending"], 409);
}

$ins = $pdo->prepare("INSERT INTO enrollments (user_id, course_id) VALUES (?, ?)");
$ins->execute([$user_id, $course_id]);

json_response(["message" => "Enrollment request sent"]);
?>
