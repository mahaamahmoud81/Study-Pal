<?php
require_once __DIR__ . "/../includes/db_connect.php";
session_start();

if (!isset($_SESSION['isLoggedIn'])) {
    http_response_code(401);
    exit("Unauthorized");
}

$user_id    = $_SESSION['user_id'];
$contact_id = (int)($_GET['contact_id'] ?? 0);

$stmt = $pdo->prepare("
    SELECT sender_id, receiver_id, message, created_at
    FROM messages
    WHERE
        (sender_id = ? AND receiver_id = ?)
        OR
        (sender_id = ? AND receiver_id = ?)
    ORDER BY created_at ASC
");

$stmt->execute([$user_id, $contact_id, $contact_id, $user_id]);

echo json_encode($stmt->fetchAll());
