<?php
session_start();
require_once __DIR__ . "/../includes/db_connect.php";
require_once __DIR__ . "/../includes/functions.php";

// Check login
if (!isset($_SESSION['isLoggedIn'])) {
    json_response(["error" => "Not logged in"], 401);
}

$user_id = $_SESSION['user_id'];
$course_id = (int)($_GET['course_id'] ?? 0);

if (!$course_id) {
    json_response(["error" => "course_id required"], 400);
}

// Check if student is enrolled
$enroll = $pdo->prepare("
    SELECT id FROM enrollments
    WHERE user_id = ? AND course_id = ? AND status = 'approved'
");
$enroll->execute([$user_id, $course_id]);

if (!$enroll->fetch()) {
    json_response(["error" => "Not enrolled"], 403);
}

// Get resources
$res = $pdo->prepare("
    SELECT r.id, r.file_name, r.file_path, r.uploaded_by, r.uploaded_at,
           u.full_name AS uploaded_by_name
    FROM resources r
    JOIN users u ON r.uploaded_by = u.id
    WHERE r.course_id = ?
");
$res->execute([$course_id]);

json_response(["resources" => $res->fetchAll()]);
