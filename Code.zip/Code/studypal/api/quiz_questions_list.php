<?php
require_once __DIR__ . "/../includes/db_connect.php";
session_start();

// Must be tutor or admin
if (!isset($_SESSION['isLoggedIn']) || !in_array($_SESSION['role'], ['tutor', 'admin'])) {
    http_response_code(401);
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

$quiz_id = (int)($_GET['quiz_id'] ?? 0);
if (!$quiz_id) {
    http_response_code(400);
    echo json_encode(["error" => "quiz_id required"]);
    exit;
}

// Fetch quiz questions
$stmt = $pdo->prepare("
    SELECT id, question, option_a, option_b, option_c, option_d, correct_answer
    FROM quiz_questions
    WHERE quiz_id = ?
    ORDER BY id ASC
");
$stmt->execute([$quiz_id]);
$questions = $stmt->fetchAll();

if (!$questions) {
    echo json_encode(["message" => "No questions found for this quiz"]);
    exit;
}

echo json_encode(["quiz_id" => $quiz_id, "questions" => $questions]);
exit;
