<?php
session_start();
require_once "../includes/db_connect.php";

if ($_SESSION["role"] !== "tutor") {
    die("Unauthorized");
}

$courseId = $_POST["course_id"];
$title = $_POST["title"];
$total = $_POST["total_marks"];
$tutorId = $_SESSION["user_id"];

$stmt = $pdo->prepare("
    INSERT INTO quizzes (course_id, tutor_id, title, total_marks)
    VALUES (?, ?, ?, ?)
");
$stmt->execute([$courseId, $tutorId, $title, $total]);

header("Location: /studypal/frontend/tutor_home_profile.php");
exit;
