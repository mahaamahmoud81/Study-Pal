<?php
session_start();

require_once __DIR__ . "/../includes/db_connect.php";
require_once __DIR__ . "/../includes/functions.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    json_response(["error" => "POST required"], 405);
}

if (!isset($_SESSION["isLoggedIn"]) || !in_array(($_SESSION["role"] ?? ""), ["tutor", "admin"], true)) {
    json_response(["error" => "Unauthorized"], 401);
}

$enrollment_id = (int)($_POST["enrollment_id"] ?? 0);
$action        = $_POST["action"] ?? "approve"; // approve | reject

if ($enrollment_id <= 0) {
    json_response(["error" => "enrollment_id required"], 400);
}

$st = $pdo->prepare("
    SELECT e.id, e.course_id, e.user_id, e.status, c.tutor_id
    FROM enrollments e
    JOIN courses c ON c.id = e.course_id
    WHERE e.id = ?
");
$st->execute([$enrollment_id]);
$row = $st->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    json_response(["error" => "Enrollment not found"], 404);
}

// tutor can only approve enrollments for their own course
if (($_SESSION["role"] ?? "") === "tutor" && (int)($_SESSION["user_id"] ?? 0) !== (int)$row["tutor_id"]) {
    json_response(["error" => "Forbidden"], 403);
}

$status = ($action === "reject") ? "rejected" : "approved";

$upd = $pdo->prepare("UPDATE enrollments SET status = ? WHERE id = ?");
$upd->execute([$status, $enrollment_id]);

json_response(["message" => "Enrollment " . $status, "enrollment_id" => $enrollment_id]);
