<?php
session_start();
header("Content-Type: application/json");

if (!isset($_SESSION["isLoggedIn"])) {
    http_response_code(401);
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

$tryFiles = [
    __DIR__ . "/../auth/db.php",
    __DIR__ . "/../includes/db_connect.php",
    __DIR__ . "/../includes/db.php",
];
foreach ($tryFiles as $f) {
    if (file_exists($f)) {
        require_once $f;
        break;
    }
}
if (!isset($pdo) || !$pdo) {
    http_response_code(500);
    echo json_encode(["error" => "DB connection not found"]);
    exit;
}

$me = (int)($_SESSION["user_id"] ?? 0);

function table_columns(PDO $pdo, string $table): array {
    $stmt = $pdo->prepare("
        SELECT COLUMN_NAME
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?
    ");
    $stmt->execute([$table]);
    return array_map(fn($r) => $r["COLUMN_NAME"], $stmt->fetchAll(PDO::FETCH_ASSOC));
}
function first_existing(array $cols, array $candidates): ?string {
    foreach ($candidates as $c) if (in_array($c, $cols, true)) return $c;
    return null;
}

$msgCols  = table_columns($pdo, "messages");
$userCols = table_columns($pdo, "users");

$senderCol = first_existing($msgCols, ["sender_id","from_id"]);
$recvCol   = first_existing($msgCols, ["receiver_id","to_id"]);
$bodyCol   = first_existing($msgCols, ["message","body","content","text"]);
$timeCol   = first_existing($msgCols, ["sent_at","created_at","time","date"]);

$userIdCol = in_array("id", $userCols, true) ? "id" : null;
$nameCol   = first_existing($userCols, ["full_name","name"]);
$roleCol   = first_existing($userCols, ["role"]);

if (!$senderCol || !$recvCol || !$bodyCol || !$userIdCol || !$nameCol) {
    http_response_code(500);
    echo json_encode(["error" => "Messages/users schema not compatible"]);
    exit;
}

$sql = "
    SELECT m.*, 
           CASE WHEN m.$senderCol = :me THEN m.$recvCol ELSE m.$senderCol END AS other_user_id
    FROM messages m
    WHERE m.$senderCol = :me OR m.$recvCol = :me
";
if ($timeCol) $sql .= " ORDER BY m.$timeCol DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute([":me" => $me]);

$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Build conversations map (latest message per other_user_id)
$convos = [];
foreach ($rows as $r) {
    $other = (int)$r["other_user_id"];
    if ($other <= 0) continue;

    $ts = $timeCol && !empty($r[$timeCol]) ? strtotime((string)$r[$timeCol]) : time();
    if (!isset($convos[$other]) || $ts > $convos[$other]["_ts"]) {
        $convos[$other] = [
            "other_user_id" => $other,
            "last_message" => (string)($r[$bodyCol] ?? ""),
            "_ts" => $ts,
        ];
    }
}

// Load user names/roles for the other participants
$otherIds = array_keys($convos);
if (count($otherIds) === 0) {
    echo json_encode(["conversations" => []]);
    exit;
}

$in = implode(",", array_fill(0, count($otherIds), "?"));
$uSql = "SELECT $userIdCol AS id, $nameCol AS full_name" . ($roleCol ? ", $roleCol AS role" : "") . " FROM users WHERE $userIdCol IN ($in)";
$uStmt = $pdo->prepare($uSql);
$uStmt->execute($otherIds);
$users = [];
foreach ($uStmt->fetchAll(PDO::FETCH_ASSOC) as $u) {
    $users[(int)$u["id"]] = $u;
}

$out = [];
foreach ($convos as $otherId => $c) {
    $name = $users[$otherId]["full_name"] ?? "User";
    $role = $roleCol ? ($users[$otherId]["role"] ?? "") : "";

    $parts = preg_split('/\s+/', trim((string)$name));
    $initials = "??";
    if ($parts && count($parts) >= 2) $initials = strtoupper(mb_substr($parts[0],0,1).mb_substr($parts[1],0,1));
    elseif ($parts && count($parts) === 1 && $parts[0] !== "") $initials = strtoupper(mb_substr($parts[0],0,2));

    $diff = time() - (int)$c["_ts"];
    if ($diff < 60) $label = "Now";
    elseif ($diff < 3600) $label = floor($diff/60) . "m";
    elseif ($diff < 86400) $label = floor($diff/3600) . "h";
    else $label = floor($diff/86400) . "d";

    // Unread requires a read flag column; if you don't have it, keep 0 (real).
    $unread = 0;

    $out[] = [
        "other_user_id" => (int)$otherId,
        "other_name" => (string)$name,
        "other_role" => (string)$role,
        "other_initials" => $initials,
        "last_message" => (string)$c["last_message"],
        "last_time_label" => $label,
        "unread" => $unread,
    ];
}

// Sort by ts desc
usort($out, function($a, $b) use ($convos) {
    return ($convos[$b["other_user_id"]]["_ts"] ?? 0) <=> ($convos[$a["other_user_id"]]["_ts"] ?? 0);
});

echo json_encode(["conversations" => $out]);
exit;
