<?php
require_once __DIR__ . "/../includes/db_connect.php";
header("Content-Type: application/json; charset=utf-8");
session_start();

if (!isset($_SESSION['isLoggedIn']) || ($_SESSION['role'] ?? '') !== 'tutor') {
    http_response_code(401);
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

$user_id = (int)$_SESSION['user_id'];

/* Find tutor_profiles.id using users.id */
$stmt = $pdo->prepare("SELECT id FROM tutor_profiles WHERE user_id = ?");
$stmt->execute([$user_id]);
$tutor = $stmt->fetch();

if (!$tutor) {
    echo json_encode([
        "courses" => [],
        "pending_requests" => [],
        "approved_students" => []
    ]);
    exit;
}

$tutor_profile_id = (int)$tutor['id'];

/* Tutor courses */
$courses = $pdo->prepare("
    SELECT id, title, subject, level
    FROM courses
    WHERE tutor_id = ?
");
$courses->execute([$tutor_profile_id]);

/* Pending students */
$pending = $pdo->prepare("
    SELECT e.id, u.id AS student_id, u.full_name, c.title
    FROM enrollments e
    JOIN users u ON u.id = e.student_id
    JOIN courses c ON c.id = e.course_id
    WHERE c.tutor_id = ? AND e.status = 'pending'
");
$pending->execute([$tutor_profile_id]);

/* Approved students */
$approved = $pdo->prepare("
    SELECT u.id AS student_id, u.full_name, c.title
    FROM enrollments e
    JOIN users u ON u.id = e.student_id
    JOIN courses c ON c.id = e.course_id
    WHERE c.tutor_id = ? AND e.status = 'approved'
");
$approved->execute([$tutor_profile_id]);

echo json_encode([
    "courses" => $courses->fetchAll(),
    "pending_requests" => $pending->fetchAll(),
    "approved_students" => $approved->fetchAll()
]);
exit;
