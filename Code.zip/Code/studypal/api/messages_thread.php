<?php
session_start();
header("Content-Type: application/json");

if (!isset($_SESSION["isLoggedIn"])) {
    http_response_code(401);
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

$tryFiles = [
    __DIR__ . "/../auth/db.php",
    __DIR__ . "/../includes/db_connect.php",
    __DIR__ . "/../includes/db.php",
];
foreach ($tryFiles as $f) {
    if (file_exists($f)) {
        require_once $f;
        break;
    }
}
if (!isset($pdo) || !$pdo) {
    http_response_code(500);
    echo json_encode(["error" => "DB connection not found"]);
    exit;
}

$me = (int)($_SESSION["user_id"] ?? 0);
$other = (int)($_GET["user_id"] ?? 0);

if ($other <= 0) {
    http_response_code(400);
    echo json_encode(["error" => "user_id required"]);
    exit;
}

function table_columns(PDO $pdo, string $table): array {
    $stmt = $pdo->prepare("
        SELECT COLUMN_NAME
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?
    ");
    $stmt->execute([$table]);
    return array_map(fn($r) => $r["COLUMN_NAME"], $stmt->fetchAll(PDO::FETCH_ASSOC));
}
function first_existing(array $cols, array $candidates): ?string {
    foreach ($candidates as $c) if (in_array($c, $cols, true)) return $c;
    return null;
}

$msgCols = table_columns($pdo, "messages");
$senderCol = first_existing($msgCols, ["sender_id","from_id"]);
$recvCol   = first_existing($msgCols, ["receiver_id","to_id"]);
$bodyCol   = first_existing($msgCols, ["message","body","content","text"]);
$timeCol   = first_existing($msgCols, ["sent_at","created_at","time","date"]);

if (!$senderCol || !$recvCol || !$bodyCol) {
    http_response_code(500);
    echo json_encode(["error" => "Messages schema not compatible"]);
    exit;
}

$sql = "
    SELECT m.*
    FROM messages m
    WHERE (m.$senderCol = ? AND m.$recvCol = ?)
       OR (m.$senderCol = ? AND m.$recvCol = ?)
";
if ($timeCol) $sql .= " ORDER BY m.$timeCol ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute([$me, $other, $other, $me]);

$out = [];
foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $m) {
    $ts = $timeCol && !empty($m[$timeCol]) ? strtotime((string)$m[$timeCol]) : time();
    $label = date("h:i A", $ts);

    $out[] = [
        "body" => (string)($m[$bodyCol] ?? ""),
        "is_sent" => ((int)($m[$senderCol] ?? 0) === $me),
        "time_label" => $label,
    ];
}

echo json_encode(["messages" => $out]);
exit;
