<?php
session_start();
require_once "includes/db_connect.php";

// admin only
if (!isset($_SESSION["isLoggedIn"]) || $_SESSION["role"] !== "admin") {
    die("Access denied.");
}

// Fetch tutor applications
$tutors = $pdo->query("
    SELECT id, full_name, email, dob, approved, qualification, subject, rate, level
    FROM users 
    WHERE role = 'tutor'
")->fetchAll();

// Count stats
$total_users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$pending_tutors = $pdo->query("SELECT COUNT(*) FROM users WHERE role='tutor' AND approved=0")->fetchColumn();
$approved_tutors = $pdo->query("SELECT COUNT(*) FROM users WHERE role='tutor' AND approved=1")->fetchColumn();

?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body { font-family: Arial; margin: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px; }
        th { background: #f0f0f0; }
        .pending { color: red; }
        .approved { color: green; }
        button { padding: 6px 12px; margin: 3px; }
    </style>
</head>
<body>

<h1>Admin Dashboard</h1>

<h3>Site Statistics</h3>
<ul>
    <li>Total Users: <b><?= $total_users ?></b></li>
    <li>Pending Tutor Applications: <b><?= $pending_tutors ?></b></li>
    <li>Approved Tutors: <b><?= $approved_tutors ?></b></li>
</ul>

<h2>Tutor Applications</h2>

<table>
<thead>
<tr>
    <th>Name</th>
    <th>Email</th>
    <th>DOB</th>
    <th>Subject</th>
    <th>Level</th>
    <th>Qualification</th>
    <th>Rate (£/hr)</th>
    <th>Status</th>
    <th>Action</th>
</tr>
</thead>
<tbody>

<?php foreach ($tutors as $t): ?>
<tr>
    <td><?= htmlspecialchars($t["full_name"]) ?></td>
    <td><?= htmlspecialchars($t["email"]) ?></td>
    <td><?= $t["dob"] ?></td>
    <td><?= htmlspecialchars($t["subject"]) ?></td>
    <td><?= htmlspecialchars($t["level"]) ?></td>
    <td><?= htmlspecialchars($t["qualification"]) ?></td>
    <td><?= htmlspecialchars($t["rate"]) ?></td>
    <td>
        <?php if ($t["approved"]): ?>
            <span class="approved">Approved</span>
        <?php else: ?>
            <span class="pending">Pending</span>
        <?php endif; ?>
    </td>
    <td>
        <?php if (!$t["approved"]): ?>
            <form action="api/admin_approve.php" method="POST" style="display:inline;">
                <input type="hidden" name="id" value="<?= $t['id'] ?>">
                <input type="hidden" name="action" value="approve">
                <button>Approve</button>
            </form>

            <form action="api/admin_approve.php" method="POST" style="display:inline;">
                <input type="hidden" name="id" value="<?= $t['id'] ?>">
                <input type="hidden" name="action" value="reject">
                <button style="background:#ffdddd;">Reject</button>
            </form>
        <?php else: ?>
            <b>✔ Active Tutor</b>
        <?php endif; ?>
    </td>
</tr>
<?php endforeach; ?>

</tbody>
</table>

</body>
</html>
