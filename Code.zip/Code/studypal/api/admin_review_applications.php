<?php
require_once __DIR__ . "/../includes/db_connect.php";
require_once __DIR__ . "/../includes/functions.php";
session_start();

// Admin only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    json_response(["error" => "Unauthorized"], 403);
}

$apps = $pdo->query("SELECT * FROM tutor_applications WHERE status='pending'")->fetchAll();

json_response(["applications" => $apps]);
