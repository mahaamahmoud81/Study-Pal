<?php
require_once __DIR__ . "/../includes/db_connect.php";
session_start();

if ($_SESSION['role'] !== 'parent') {
    http_response_code(401);
    exit;
}

$parent_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("
    SELECT m.message, m.created_at, u.full_name AS sender
    FROM messages m
    JOIN users u ON u.id = m.sender_id
    WHERE m.receiver_id = ?
    ORDER BY m.created_at ASC
");
$stmt->execute([$parent_id]);

echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
