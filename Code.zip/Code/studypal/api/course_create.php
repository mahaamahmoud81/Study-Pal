<?php
// create course (POST)
// expects: title, description, level, subject
require_once __DIR__ . "/../includes/db_connect.php";
require_once __DIR__ . "/../includes/functions.php";
session_start();

if (!isset($_SESSION['isLoggedIn'])) json_response(['error'=>'Unauthorized'], 401);
if (!in_array($_SESSION['role'], ['tutor','admin'])) json_response(['error'=>'Forbidden'], 403);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_response(['error'=>'POST required'], 405);

$title = trim($_POST['title'] ?? '');
$desc  = trim($_POST['description'] ?? '');
$level = $_POST['level'] ?? 'Other';
$subject = trim($_POST['subject'] ?? '');  // NEW
$tutor_id = ($_SESSION['role'] === 'tutor') ? $_SESSION['user_id'] : ($_POST['tutor_id'] ?? null);

if (!$title) json_response(['error'=>'Title required'], 400);
if (!$subject) json_response(['error'=>'Subject required'], 400);  // NEW

$stmt = $pdo->prepare("
    INSERT INTO courses (title, description, level, subject, tutor_id)
    VALUES (?, ?, ?, ?, ?)
");
$stmt->execute([$title, $desc, $level, $subject, $tutor_id]);

json_response(['message'=>'Course created','course_id'=>$pdo->lastInsertId()],201);
