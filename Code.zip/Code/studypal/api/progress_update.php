<?php
require_once __DIR__ . "/../includes/db_connect.php";
session_start();

// Must be logged in & a tutor
if (!isset($_SESSION['isLoggedIn']) || $_SESSION['role'] !== 'tutor') {
    http_response_code(401);
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

$student_id = (int)($_POST['student_id'] ?? 0);
$course_id  = (int)($_POST['course_id'] ?? 0);
$progress   = (int)($_POST['progress_percent'] ?? -1); // form uses progress_percent

// Validate
if (!$student_id || !$course_id) {
    http_response_code(400);
    echo json_encode(["error" => "student_id and course_id required"]);
    exit;
}

if ($progress < 0 || $progress > 100) {
    http_response_code(400);
    echo json_encode(["error" => "Invalid progress value (0–100 only)"]);
    exit;
}

// Check that tutor owns the course
$chk = $pdo->prepare("SELECT id FROM courses WHERE id = ? AND tutor_id = ?");
$chk->execute([$course_id, $_SESSION['user_id']]);
if (!$chk->fetch()) {
    http_response_code(403);
    echo json_encode(["error" => "You are not the tutor of this course"]);
    exit;
}

// Insert or update progress
$exists = $pdo->prepare("SELECT id FROM progress WHERE user_id = ? AND course_id = ?");
$exists->execute([$student_id, $course_id]);

if ($exists->fetch()) {
    // update
    $upd = $pdo->prepare("UPDATE progress SET progress = ? WHERE user_id = ? AND course_id = ?");
    $upd->execute([$progress, $student_id, $course_id]);
} else {
    // insert new
    $ins = $pdo->prepare("INSERT INTO progress (user_id, course_id, progress) VALUES (?, ?, ?)");
    $ins->execute([$student_id, $course_id, $progress]);
}

echo json_encode(["message" => "Progress updated"]);
exit;
