<?php
require_once __DIR__ . "/../includes/db_connect.php";
require_once __DIR__ . "/../includes/functions.php";
session_start();

// Must be tutor
if (!isset($_SESSION['isLoggedIn']) || $_SESSION['role'] !== 'tutor') {
    http_response_code(401);
    echo "Unauthorized";
    exit;
}

// Must use POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo "POST required";
    exit;
}

// Validate course ID
$course_id = (int)($_POST['course_id'] ?? 0);
if (!$course_id) {
    http_response_code(400);
    echo "course_id required";
    exit;
}

// Validate file exists
if (!isset($_FILES['file'])) {
    http_response_code(400);
    echo "file required";
    exit;
}

// Allowed MIME types
$allowed_mime = [
    'application/pdf',
    'image/png',
    'image/jpeg',
    'application/vnd.ms-powerpoint', // .ppt
    'application/vnd.openxmlformats-officedocument.presentationml.presentation', // .pptx
    'application/msword', // .doc
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document', // .docx
    'text/plain',
    'application/vnd.ms-excel', // .xls
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' // .xlsx
];

// Allowed extensions
$allowed_ext = [
    'pdf','png','jpg','jpeg','ppt','pptx','doc','docx','txt','xls','xlsx'
];

$file = $_FILES['file'];

if ($file['error'] !== 0) {
    http_response_code(400);
    echo "Upload error";
    exit;
}

$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

// Check extension allowed
if (!in_array($ext, $allowed_ext)) {
    http_response_code(400);
    echo "File extension not allowed";
    exit;
}

// Check MIME allowed
$mime = mime_content_type($file['tmp_name']);
if (!in_array($mime, $allowed_mime)) {
    http_response_code(400);
    echo "File type not allowed";
    exit;
}

// Generate safe name
$safeName = bin2hex(random_bytes(8)) . '.' . $ext;
$dest = __DIR__ . "/../uploads/" . $safeName;

// Move file
if (!move_uploaded_file($file['tmp_name'], $dest)) {
    http_response_code(500);
    echo "Move failed";
    exit;
}

// Insert into DB
$insert = $pdo->prepare("
    INSERT INTO resources (course_id, file_name, file_path, uploaded_by)
    VALUES (?, ?, ?, ?)
");

$insert->execute([
    $course_id,
    $file['name'],
    'uploads/' . $safeName,
    $_SESSION['user_id']
]);

// Redirect tutor
header('Location: /studypal/dashboard.php');
exit;
