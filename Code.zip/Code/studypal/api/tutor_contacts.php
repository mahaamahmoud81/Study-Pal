<?php
require_once __DIR__ . "/../includes/db_connect.php";
session_start();
header("Content-Type: application/json");

$stmt = $pdo->prepare("
  SELECT DISTINCT u.id, u.full_name
  FROM tutor_profiles tp
  JOIN courses c ON c.tutor_id = tp.id
  JOIN enrollments e ON e.course_id = c.id
  JOIN users u ON u.id = e.student_id
  WHERE tp.user_id = ? AND e.status='approved'
");
$stmt->execute([$_SESSION['user_id']]);

$contacts=[];
foreach($stmt as $r){
  $contacts[]=[
    "id"=>$r['id'],
    "name"=>$r['full_name'],
    "type"=>"student",
    "lastMessage"=>"",
    "unread"=>0,
    "timestamp"=>""
  ];
}
echo json_encode(["contacts"=>$contacts]);
