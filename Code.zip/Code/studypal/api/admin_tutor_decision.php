<?php
require_once __DIR__ . "/../includes/db_connect.php";
require_once __DIR__ . "/../includes/functions.php";
session_start();

if ($_SESSION['role'] !== 'admin') json_response(["error"=>"Forbidden"],403);

$app_id = (int)($_POST['application_id'] ?? 0);
$action = $_POST['action'] ?? '';

if (!$app_id) json_response(["error"=>"application_id required"],400);

$app = $pdo->prepare("SELECT * FROM tutor_applications WHERE id=?");
$app->execute([$app_id]);
$data = $app->fetch();

if (!$data) json_response(["error"=>"Application not found"],404);

if ($action === "approve") {
    // create tutor user
    $pass = password_hash("Tutor123!", PASSWORD_DEFAULT);

    $ins = $pdo->prepare("INSERT INTO users (full_name, email, dob, password, role, approved) VALUES (?, ?, ?, ?, 'tutor', 1)");
    $fullname = $data['forename'] . " " . $data['surname'];
    $ins->execute([$fullname, $data['email'], $data['dob'], $pass]);

    $pdo->prepare("UPDATE tutor_applications SET status='approved' WHERE id=?")->execute([$app_id]);

    json_response(["message"=>"Tutor approved and account created"]);
}

if ($action === "reject") {
    $pdo->prepare("UPDATE tutor_applications SET status='rejected' WHERE id=?")->execute([$app_id]);
    json_response(["message"=>"Application rejected"]);
}

json_response(["error"=>"Invalid action"],400);
