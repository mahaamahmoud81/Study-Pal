<?php
require_once __DIR__ . "/../includes/db_connect.php";
header("Content-Type: application/json");

// Get unique subjects from courses table
$stmt = $pdo->query("SELECT DISTINCT subject FROM courses ORDER BY subject ASC");
$subjects = $stmt->fetchAll(PDO::FETCH_COLUMN);

echo json_encode(["subjects" => $subjects]);
