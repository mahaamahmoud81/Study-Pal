<?php
session_start();
header("Content-Type: application/json");

if (!isset($_SESSION["isLoggedIn"])) {
    http_response_code(401);
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

$tryFiles = [
    __DIR__ . "/../auth/db.php",
    __DIR__ . "/../includes/db_connect.php",
    __DIR__ . "/../includes/db.php",
];
foreach ($tryFiles as $f) {
    if (file_exists($f)) {
        require_once $f;
        break;
    }
}
if (!isset($pdo) || !$pdo) {
    http_response_code(500);
    echo json_encode(["error" => "DB connection not found"]);
    exit;
}

$senderId   = (int)($_SESSION["user_id"] ?? 0);
$receiverId = (int)($_POST["receiver_id"] ?? 0);
$body       = trim((string)($_POST["body"] ?? ""));

if ($receiverId <= 0) {
    http_response_code(400);
    echo json_encode(["error" => "receiver_id required"]);
    exit;
}
if ($body === "") {
    http_response_code(400);
    echo json_encode(["error" => "Message body required"]);
    exit;
}

function table_columns(PDO $pdo, string $table): array {
    $stmt = $pdo->prepare("
        SELECT COLUMN_NAME
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?
    ");
    $stmt->execute([$table]);
    return array_map(fn($r) => $r["COLUMN_NAME"], $stmt->fetchAll(PDO::FETCH_ASSOC));
}
function first_existing(array $cols, array $candidates): ?string {
    foreach ($candidates as $c) if (in_array($c, $cols, true)) return $c;
    return null;
}

$msgCols = table_columns($pdo, "messages");
$userCols = table_columns($pdo, "users");

$senderCol = first_existing($msgCols, ["sender_id","from_id"]);
$recvCol   = first_existing($msgCols, ["receiver_id","to_id"]);
$bodyCol   = first_existing($msgCols, ["message","body","content","text"]);

$userIdCol = in_array("id", $userCols, true) ? "id" : null;

if (!$senderCol || !$recvCol || !$bodyCol || !$userIdCol) {
    http_response_code(500);
    echo json_encode(["error" => "Schema not compatible"]);
    exit;
}

// Validate receiver exists
$chk = $pdo->prepare("SELECT $userIdCol FROM users WHERE $userIdCol = ?");
$chk->execute([$receiverId]);
if (!$chk->fetch()) {
    http_response_code(404);
    echo json_encode(["error" => "Receiver not found"]);
    exit;
}

// Insert message
$sql = "INSERT INTO messages ($senderCol, $recvCol, $bodyCol) VALUES (?, ?, ?)";
$stmt = $pdo->prepare($sql);
$stmt->execute([$senderId, $receiverId, $body]);

echo json_encode(["message" => "sent"]);
exit;
