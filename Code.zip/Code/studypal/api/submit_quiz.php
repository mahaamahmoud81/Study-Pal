<?php
session_start();
require_once "../includes/db_connect.php";

$quizId = $_POST["quiz_id"];
$score = $_POST["score"];
$studentId = $_SESSION["user_id"];

$stmt = $pdo->prepare("
    INSERT INTO quiz_results (quiz_id, student_id, score)
    VALUES (?, ?, ?)
");
$stmt->execute([$quizId, $studentId, $score]);

header("Location: /studypal/frontend/student_home_profile.php");
exit;
