<?php
session_start();
require_once __DIR__ . "/../includes/db_connect.php";

if (!isset($_SESSION['isLoggedIn']) || $_SESSION['role']!=='tutor'){
  header("Location:/studypal/frontend/login.html"); exit;
}

$stmt=$pdo->prepare("
 SELECT COUNT(*) FROM tutor_profiles tp
 JOIN courses c ON c.tutor_id=tp.id
 WHERE tp.user_id=?
");
$stmt->execute([$_SESSION['user_id']]);
$hasCourses=$stmt->fetchColumn()>0;

include __DIR__."/upload-resources.html";
?>

<script>
function logout(){window.location.href="/studypal/auth/logout.php";}
const REAL=<?= $hasCourses?'true':'false' ?>;
if(!REAL) console.log("Demo resources mode");
</script>
