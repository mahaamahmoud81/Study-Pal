<?php
session_start();
require_once __DIR__."/../includes/db_connect.php";

if(!isset($_SESSION['isLoggedIn'])||$_SESSION['role']!=='tutor'){
 header("Location:/studypal/frontend/login.html"); exit;
}

include __DIR__."/quiz-results.html";
?>

<script>
function logout(){window.location.href="/studypal/auth/logout.php";}

fetch("/studypal/api/quiz_results_tutor.php")
 .then(r=>r.json())
 .then(d=>console.log("Quiz results:",d));
</script>
