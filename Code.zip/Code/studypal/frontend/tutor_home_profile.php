<?php
session_start();

if (!isset($_SESSION['isLoggedIn']) || ($_SESSION['role'] ?? '') !== 'tutor') {
    header("Location: /studypal/frontend/login.html");
    exit;
}

require_once __DIR__ . "/../includes/db_connect.php";

/* Check if this tutor owns real courses */
$stmt = $pdo->prepare("
    SELECT COUNT(*) 
    FROM tutor_profiles tp
    JOIN courses c ON c.tutor_id = tp.id
    WHERE tp.user_id = ?
");
$stmt->execute([$_SESSION['user_id']]);
$hasRealData = $stmt->fetchColumn() > 0;

/* Load UI unchanged */
include __DIR__ . "/tutor_home_profile.html";
?>

<script>
function logout() {
  window.location.href = "/studypal/auth/logout.php";
}

document.addEventListener('DOMContentLoaded', () => {
  const HAS_REAL_DATA = <?= $hasRealData ? 'true' : 'false' ?>;
  if (!HAS_REAL_DATA) return; // demo tutors remain demo

  // Replace welcome name
  const h1 = document.querySelector('.welcome-content h1');
  if (h1) h1.textContent = "Welcome back, <?= htmlspecialchars($_SESSION['full_name']) ?>!";

  // Load real dashboard stats
  fetch("/studypal/api/dashboard_tutor.php", { credentials: "same-origin" })
    .then(r => r.json())
    .then(d => {
      document.getElementById("totalCourses").textContent  = d.courses.length;
      document.getElementById("pendingAssignments").textContent = d.pending_requests.length;

      const students = new Set(d.approved_students.map(s => s.student_id));
      document.getElementById("totalStudents").textContent = students.size;
    });
});
</script>
