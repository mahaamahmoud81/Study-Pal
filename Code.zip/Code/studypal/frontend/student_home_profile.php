<?php
session_start();

// Require login + student role
if (!isset($_SESSION["isLoggedIn"]) || ($_SESSION["role"] ?? "") !== "student") {
    header("Location: login.html");
    exit;
}

// Load DB (supports your current folder structure)
$pdo = null;
$tryFiles = [
    __DIR__ . "/../auth/db.php",
    __DIR__ . "/../includes/db_connect.php",
    __DIR__ . "/../includes/db.php",
];
foreach ($tryFiles as $f) {
    if (file_exists($f)) {
        require_once $f;
        break;
    }
}
if (!isset($pdo) || !$pdo) {
    die("DB connection not found. Expected auth/db.php or includes/db_connect.php");
}

$studentId = (int)($_SESSION["user_id"] ?? 0);
$fullName  = (string)($_SESSION["full_name"] ?? "Student");

// Initials
$initials = "ST";
$parts = preg_split('/\s+/', trim($fullName));
if ($parts && count($parts) >= 2) {
    $initials = strtoupper(mb_substr($parts[0], 0, 1) . mb_substr($parts[1], 0, 1));
} elseif ($parts && count($parts) === 1 && $parts[0] !== "") {
    $initials = strtoupper(mb_substr($parts[0], 0, 2));
}

// Helper: read table columns (so we don't break if your column names differ)
function table_columns(PDO $pdo, string $table): array {
    $stmt = $pdo->prepare("
        SELECT COLUMN_NAME
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?
    ");
    $stmt->execute([$table]);
    return array_map(fn($r) => $r["COLUMN_NAME"], $stmt->fetchAll(PDO::FETCH_ASSOC));
}

function first_existing(array $cols, array $candidates): ?string {
    foreach ($candidates as $c) {
        if (in_array($c, $cols, true)) return $c;
    }
    return null;
}

// Column detection
$enrollmentCols = table_columns($pdo, "enrollments");
$courseCols     = table_columns($pdo, "courses");
$resourceCols   = table_columns($pdo, "resources");
$messageCols    = table_columns($pdo, "messages");
$userCols       = table_columns($pdo, "users");

$enUserCol = in_array("student_id", $enrollmentCols, true)
    ? "student_id"
    : (in_array("user_id", $enrollmentCols, true) ? "user_id" : null);
$enCourseCol = in_array("course_id", $enrollmentCols, true) ? "course_id" : null;
$enStatusCol = first_existing($enrollmentCols, ["status", "approval_status"]);

$courseIdCol   = in_array("id", $courseCols, true) ? "id" : null;
$courseTitleCol= first_existing($courseCols, ["title", "name"]);
$courseDescCol = first_existing($courseCols, ["description", "details"]);

$resCourseCol  = in_array("course_id", $resourceCols, true) ? "course_id" : null;
$resFileCol    = first_existing($resourceCols, ["file_name", "filename", "name", "file"]);
$resTimeCol    = first_existing($resourceCols, ["uploaded_at", "created_at", "added_at", "date"]);

$msgSenderCol  = first_existing($messageCols, ["sender_id", "from_id"]);
$msgRecvCol    = first_existing($messageCols, ["receiver_id", "to_id"]);
$msgBodyCol    = first_existing($messageCols, ["message", "body", "content", "text"]);
$msgTimeCol    = first_existing($messageCols, ["sent_at", "created_at", "time", "date"]);

$userIdCol     = in_array("id", $userCols, true) ? "id" : null;
$userNameCol   = first_existing($userCols, ["full_name", "name"]);

// Counts (real)
$activeCourses = 0;
$resourceCount = 0;

// Active courses count
try {
    if ($enUserCol && $enCourseCol) {
        if ($enStatusCol) {
            $q = $pdo->prepare("SELECT COUNT(*) AS c FROM enrollments WHERE {$enUserCol}=? AND {$enStatusCol}='approved'");
            $q->execute([$studentId]);
        } else {
            $q = $pdo->prepare("SELECT COUNT(*) AS c FROM enrollments WHERE {$enUserCol}=?");
            $q->execute([$studentId]);
        }
        $activeCourses = (int)($q->fetch(PDO::FETCH_ASSOC)["c"] ?? 0);
    }
} catch (Throwable $e) {
    $activeCourses = 0;
}

// Resource count for enrolled courses
try {
    if ($resCourseCol && $enUserCol && $enCourseCol) {
        if ($enStatusCol) {
            $q = $pdo->prepare("
                SELECT COUNT(*) AS c
                FROM resources r
                WHERE r.{$resCourseCol} IN (
                    SELECT {$enCourseCol} FROM enrollments WHERE {$enUserCol}=? AND {$enStatusCol}='approved'
                )
            ");
            $q->execute([$studentId]);
        } else {
            $q = $pdo->prepare("
                SELECT COUNT(*) AS c
                FROM resources r
                WHERE r.{$resCourseCol} IN (
                    SELECT {$enCourseCol} FROM enrollments WHERE {$enUserCol}=?
                )
            ");
            $q->execute([$studentId]);
        }
        $resourceCount = (int)($q->fetch(PDO::FETCH_ASSOC)["c"] ?? 0);
    } else {
        $resourceCount = 0;
    }
} catch (Throwable $e) {
    $resourceCount = 0;
}

// These features are not in your DB yet, so they must be real values (0) until you add tables.
$pendingAssignments = 0;
$upcomingClasses    = 0;

// Recent activity: last resources + last received messages
$recentItems = [];

// Latest resources
try {
    if ($resCourseCol && $resFileCol) {
        $sql = "
            SELECT r.* " . ($courseTitleCol ? ", c.{$courseTitleCol} AS course_title" : "") . "
            FROM resources r
            LEFT JOIN courses c ON " . ($courseIdCol ? "c.{$courseIdCol}=r.{$resCourseCol}" : "1=0") . "
        ";

        // filter to student's courses if enrollments exist
        if ($enUserCol && $enCourseCol) {
            if ($enStatusCol) {
                $sql .= " WHERE r.{$resCourseCol} IN (SELECT {$enCourseCol} FROM enrollments WHERE {$enUserCol}=? AND {$enStatusCol}='approved')";
            } else {
                $sql .= " WHERE r.{$resCourseCol} IN (SELECT {$enCourseCol} FROM enrollments WHERE {$enUserCol}=?)";
            }
        } else {
            $sql .= " WHERE 1=1 ";
        }

        if ($resTimeCol) {
            $sql .= " ORDER BY r.{$resTimeCol} DESC LIMIT 5";
        } else {
            $sql .= " LIMIT 5";
        }

        $stmt = $pdo->prepare($sql);
        if ($enUserCol && $enCourseCol) $stmt->execute([$studentId]); else $stmt->execute();
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $title = (string)($r[$resFileCol] ?? "Resource");
            $t = $resTimeCol && !empty($r[$resTimeCol]) ? strtotime((string)$r[$resTimeCol]) : time();
            $recentItems[] = [
                "type" => "resource",
                "title" => "New Resource Added: " . $title,
                "time" => $t,
            ];
        }
    }
} catch (Throwable $e) {}

// Latest received messages
try {
    if ($msgSenderCol && $msgRecvCol && $msgBodyCol && $userIdCol && $userNameCol) {
        $sql = "
            SELECT m.*, u.{$userNameCol} AS sender_name
            FROM messages m
            JOIN users u ON u.{$userIdCol} = m.{$msgSenderCol}
            WHERE m.{$msgRecvCol} = ?
        ";
        if ($msgTimeCol) $sql .= " ORDER BY m.{$msgTimeCol} DESC LIMIT 5";
        else $sql .= " LIMIT 5";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([$studentId]);
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $m) {
            $sender = (string)($m["sender_name"] ?? "Someone");
            $t = $msgTimeCol && !empty($m[$msgTimeCol]) ? strtotime((string)$m[$msgTimeCol]) : time();
            $recentItems[] = [
                "type" => "message",
                "title" => "New Message from: " . $sender,
                "time" => $t,
            ];
        }
    }
} catch (Throwable $e) {}

// Sort by time desc and take top 5
usort($recentItems, fn($a, $b) => $b["time"] <=> $a["time"]);
$recentItems = array_slice($recentItems, 0, 5);

// Format "time ago" label
function nice_time(int $ts): string {
    $diff = time() - $ts;
    if ($diff < 60) return "Just now";
    if ($diff < 3600) return floor($diff/60) . " mins ago";
    if ($diff < 86400) return floor($diff/3600) . " hours ago";
    return floor($diff/86400) . " days ago";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>StudyPals — Student Dashboard</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/styles.css">
    <link rel="stylesheet" href="assets/profile-styles.css">
    <style>
        :root {
            --accent: #3b82f6;
            --accent-dark: #2563eb;
            --accent-light: #60a5fa;
            --accent-hover: rgba(59, 130, 246, 0.1);
            --accent-active: rgba(59, 130, 246, 0.2);
            --bg: #0f172a;
            --card: #1e293b;
            --card-hover: #334155;
            --text: #f1f5f9;
            --text-muted: #94a3b8;
            --border: #334155;
            --success: #34d399;
            --danger: #f87171;
            --warning: #fbbf24;
            --purple: #8b5cf6;
            --pink: #ec4899;
            --orange: #f59e0b;
            --cyan: #06b6d4;
            --radius: 16px;
            --radius-sm: 8px;
            --shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
        }

        body {
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
            overflow-x: hidden;
        }

        .nav {
            background: var(--card);
            border-bottom: 1px solid var(--border);
            padding: 0 24px;
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 0;
        }

        .brand {
            font-size: 28px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--accent), var(--accent-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
        }

        .nav-links {
            display: flex;
            gap: 16px;
            align-items: center;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--text-muted);
            font-weight: 500;
            padding: 8px 12px;
            border-radius: var(--radius-sm);
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 14px;
        }

        .nav-links a:hover {
            color: var(--text);
            background: var(--accent-hover);
        }

        .nav-links a.active {
            color: var(--accent);
            background: var(--accent-active);
        }

        .profile-dropdown {
            position: relative;
        }

        .profile-btn {
            background: none;
            border: none;
            color: var(--text);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: var(--radius-sm);
            transition: var(--transition);
        }

        .profile-btn:hover {
            background: var(--accent-hover);
        }

        .profile-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--accent), var(--accent-dark));
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }

        .dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            min-width: 200px;
            box-shadow: var(--shadow);
            display: none;
            z-index: 1000;
        }

        .profile-dropdown:hover .dropdown-menu,
        .profile-dropdown:focus-within .dropdown-menu {
            display: block;
        }

        .dropdown-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: var(--text);
            text-decoration: none;
            transition: var(--transition);
            border-bottom: 1px solid var(--border);
        }

        .dropdown-item:last-child {
            border-bottom: none;
        }

        .dropdown-item:hover {
            background: var(--accent-hover);
            color: var(--accent);
        }

        .dropdown-item.logout {
            color: var(--danger);
        }

        .dropdown-item.logout:hover {
            background: rgba(248, 113, 113, 0.1);
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 40px 24px;
        }

        .welcome-section {
            background: var(--card);
            border-radius: var(--radius);
            padding: 40px;
            border: 1px solid var(--border);
            margin-bottom: 40px;
            position: relative;
            overflow: hidden;
        }

        .welcome-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--accent), var(--accent-dark));
        }

        .welcome-content h1 {
            font-size: 2.5rem;
            margin-bottom: 8px;
            background: linear-gradient(135deg, var(--text), var(--accent-light));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .welcome-content p {
            color: var(--text-muted);
            font-size: 1.1rem;
            margin-bottom: 24px;
        }

        .student-stats {
            display: flex;
            gap: 32px;
            margin-top: 32px;
            flex-wrap: wrap;
        }

        .stat-badge {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
            padding: 16px 24px;
            background: rgba(15, 23, 42, 0.5);
            border-radius: var(--radius);
            border: 1px solid var(--border);
            min-width: 120px;
            cursor: pointer;
            transition: var(--transition);
            text-decoration: none;
            color: inherit;
        }

        .stat-badge:hover {
            border-color: var(--accent);
            transform: translateY(-2px);
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--accent);
        }

        .stat-label {
            font-size: 0.9rem;
            color: var(--text-muted);
            text-align: center;
        }

        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }

        .dashboard-card {
            background: var(--card);
            border-radius: var(--radius);
            padding: 30px;
            border: 1px solid var(--border);
            transition: var(--transition);
            cursor: pointer;
            height: 100%;
            display: flex;
            flex-direction: column;
            text-decoration: none;
            color: inherit;
        }

        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow);
            border-color: var(--accent);
        }

        .card-header {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 20px;
        }

        .card-icon {
            width: 56px;
            height: 56px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        .card-blue .card-icon {
            background: linear-gradient(135deg, var(--accent), var(--accent-dark));
            color: white;
        }

        .card-green .card-icon {
            background: linear-gradient(135deg, var(--success), #10b981);
            color: white;
        }

        .card-purple .card-icon {
            background: linear-gradient(135deg, var(--purple), #7c3aed);
            color: white;
        }

        .card-pink .card-icon {
            background: linear-gradient(135deg, var(--pink), #db2777);
            color: white;
        }

        .card-orange .card-icon {
            background: linear-gradient(135deg, var(--orange), #d97706);
            color: white;
        }

        .card-cyan .card-icon {
            background: linear-gradient(135deg, var(--cyan), #0891b2);
            color: white;
        }

        .card-title {
            font-size: 1.4rem;
            font-weight: 600;
            color: var(--text);
            margin-bottom: 4px;
        }

        .card-subtitle {
            color: var(--text-muted);
            font-size: 0.9rem;
        }

        .card-content {
            margin-bottom: 24px;
            line-height: 1.6;
            flex: 1;
        }

        .card-actions {
            display: flex;
            gap: 12px;
            margin-top: auto;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: var(--radius-sm);
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            font-size: 0.9rem;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--accent), var(--accent-dark));
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.3);
        }

        .btn-secondary {
            background: transparent;
            border: 2px solid var(--accent);
            color: var(--accent);
        }

        .btn-secondary:hover {
            background: var(--accent-hover);
            transform: translateY(-2px);
        }

        .recent-activity {
            background: var(--card);
            border-radius: var(--radius);
            padding: 30px;
            border: 1px solid var(--border);
            margin-top: 30px;
        }

        .section-title {
            font-size: 20px;
            font-weight: 600;
            color: var(--text);
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .section-title i {
            color: var(--accent);
        }

        .activity-list {
            list-style: none;
        }

        .activity-item {
            display: flex;
            align-items: center;
            padding: 20px;
            border-bottom: 1px solid var(--border);
            transition: var(--transition);
            border-radius: 8px;
            margin-bottom: 8px;
        }

        .activity-item:hover {
            background: var(--accent-hover);
            transform: translateX(5px);
        }

        .activity-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
        }

        .activity-icon {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 18px;
            background: rgba(96, 165, 250, 0.1);
            color: var(--accent);
            border: 2px solid rgba(96, 165, 250, 0.2);
        }

        .activity-details {
            flex: 1;
        }

        .activity-title {
            font-weight: 600;
            color: var(--text);
            margin-bottom: 5px;
            font-size: 16px;
        }

        .activity-time {
            font-size: 14px;
            color: var(--text-muted);
        }

        .notification {
            position: fixed;
            top: 100px;
            right: 30px;
            padding: 16px 24px;
            background: var(--card);
            border-radius: var(--radius-sm);
            border-left: 4px solid var(--accent);
            box-shadow: var(--shadow);
            z-index: 10000;
            transform: translateX(400px);
            transition: transform 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            max-width: 400px;
        }

        .notification.active {
            transform: translateX(0);
        }

        .notification-success {
            border-left-color: var(--success);
        }

        .notification-error {
            border-left-color: var(--danger);
        }

        @media (max-width: 768px) {
            .nav-links a:not(.active) {
                display: none;
            }

            .student-stats {
                flex-wrap: wrap;
                justify-content: center;
                gap: 20px;
            }

            .stat-badge {
                min-width: 100px;
                padding: 12px 16px;
            }

            .container {
                padding: 20px 16px;
            }

            .welcome-section {
                padding: 24px;
            }

            .dashboard-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>
    <!-- Navigation -->
    <header class="nav">
        <div class="nav-container">
            <div class="brand" onclick="window.location.href='student_home_profile.php'">
                <i class="fas fa-graduation-cap"></i>
                StudyPals
            </div>
            <nav class="nav-links">
                <a href="student_home_profile.php" class="active">
                    <i class="fas fa-home"></i> Home
                </a>
                <a href="mycourses.html">
                    <i class="fas fa-book-open"></i> My Courses
                </a>
                <a href="student_messages.php">
                    <i class="fas fa-messages"></i> Messages
                </a>
                <a href="student_schedule.html">
                    <i class="fas fa-calendar-alt"></i> Schedule
                </a>
                <a href="assignments.html">
                    <i class="fas fa-tasks"></i> Assignments
                </a>
                <a href="student_analytics.html">
                    <i class="fas fa-chart-line"></i> Analytics
                </a>
                <a href="student_resources.html">
                    <i class="fas fa-folder-open"></i> Resources
                </a>
                <div class="profile-dropdown">
                    <button class="profile-btn">
                        <div class="profile-avatar"><?= htmlspecialchars($initials) ?></div>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="dropdown-menu">
                        <a href="student_profile.html" class="dropdown-item">
                            <i class="fas fa-user"></i> My Profile
                        </a>
                        <a href="student_settings.html" class="dropdown-item">
                            <i class="fas fa-cog"></i> Settings
                        </a>
                        <a href="#" class="dropdown-item logout" onclick="logout()">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>
            </nav>
        </div>
    </header>

    <!-- Main Content -->
    <main class="container">
        <!-- Welcome Section -->
        <div class="welcome-section">
            <div class="welcome-content">
                <h1>Welcome back, <?= htmlspecialchars($fullName) ?>!</h1>
                <p>Continue your learning journey, track progress, and manage your schedule</p>
                <div class="student-stats">
                    <a href="mycourses.html" class="stat-badge">
                        <span class="stat-value" id="activeCourses"><?= (int)$activeCourses ?></span>
                        <span class="stat-label">Active Courses</span>
                    </a>
                    <a href="assignments.html" class="stat-badge">
                        <span class="stat-value" id="pendingAssignments"><?= (int)$pendingAssignments ?></span>
                        <span class="stat-label">Due Assignments</span>
                    </a>
                    <a href="student_schedule.html" class="stat-badge">
                        <span class="stat-value" id="upcomingClasses"><?= (int)$upcomingClasses ?></span>
                        <span class="stat-label">Upcoming Classes</span>
                    </a>
                    <a href="student_resources.html" class="stat-badge">
                        <span class="stat-value" id="resourceCount"><?= (int)$resourceCount ?></span>
                        <span class="stat-label">Study Resources</span>
                    </a>
                </div>
            </div>
        </div>

        <!-- Dashboard Grid -->
        <div class="dashboard-grid">
            <!-- My Courses -->
            <a href="mycourses.html" class="dashboard-card card-blue">
                <div class="card-header">
                    <div class="card-icon">
                        <i class="fas fa-book-open"></i>
                    </div>
                    <div>
                        <h3 class="card-title">My Courses</h3>
                        <p class="card-subtitle">View all enrolled courses</p>
                    </div>
                </div>
                <div class="card-content">
                    <p>Access your enrolled courses, view course materials, track progress, and continue learning from
                        where you left off.</p>
                </div>
                <div class="card-actions">
                    <span class="btn btn-primary">
                        <i class="fas fa-eye"></i> View Courses
                    </span>
                    <span class="btn btn-secondary">
                        <i class="fas fa-search"></i> Browse More
                    </span>
                </div>
            </a>

            <!-- Schedule -->
            <a href="student_schedule.html" class="dashboard-card card-green">
                <div class="card-header">
                    <div class="card-icon">
                        <i class="fas fa-calendar-alt"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Schedule</h3>
                        <p class="card-subtitle">View your timetable</p>
                    </div>
                </div>
                <div class="card-content">
                    <p>View your class schedule, upcoming sessions, and manage your timetable. Never miss an important
                        class again.</p>
                </div>
                <div class="card-actions">
                    <span class="btn btn-primary">
                        <i class="fas fa-calendar"></i> View Schedule
                    </span>
                    <span class="btn btn-secondary">
                        <i class="fas fa-download"></i> Export
                    </span>
                </div>
            </a>

            <!-- Assignments -->
            <a href="assignments.html" class="dashboard-card card-purple">
                <div class="card-header">
                    <div class="card-icon">
                        <i class="fas fa-tasks"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Assignments</h3>
                        <p class="card-subtitle">Manage your tasks</p>
                    </div>
                </div>
                <div class="card-content">
                    <p>View pending assignments, submit completed work, check grades, and track submission deadlines.
                    </p>
                </div>
                <div class="card-actions">
                    <span class="btn btn-primary">
                        <i class="fas fa-list"></i> View Assignments
                    </span>
                    <span class="btn btn-secondary">
                        <i class="fas fa-upload"></i> Submit Work
                    </span>
                </div>
            </a>

            <!-- Analytics -->
            <a href="student_analytics.html" class="dashboard-card card-orange">
                <div class="card-header">
                    <div class="card-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Analytics</h3>
                        <p class="card-subtitle">Track your performance</p>
                    </div>
                </div>
                <div class="card-content">
                    <p>View detailed analytics of your academic performance, progress reports, and improvement metrics.
                    </p>
                </div>
                <div class="card-actions">
                    <span class="btn btn-primary">
                        <i class="fas fa-chart-bar"></i> View Analytics
                    </span>
                    <span class="btn btn-secondary">
                        <i class="fas fa-download"></i> Download Report
                    </span>
                </div>
            </a>

            <!-- Messages -->
            <a href="student_messages.php" class="dashboard-card card-cyan">
                <div class="card-header">
                    <div class="card-icon">
                        <i class="fas fa-messages"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Messages</h3>
                        <p class="card-subtitle">Communicate with tutors</p>
                    </div>
                </div>
                <div class="card-content">
                    <p>Message your tutors, ask questions about course material, and get help with difficult concepts.
                    </p>
                </div>
                <div class="card-actions">
                    <span class="btn btn-primary">
                        <i class="fas fa-envelope"></i> View Messages
                    </span>
                    <span class="btn btn-secondary">
                        <i class="fas fa-plus"></i> New Message
                    </span>
                </div>
            </a>

            <!-- Study Resources -->
            <a href="student_resources.html" class="dashboard-card card-pink">
                <div class="card-header">
                    <div class="card-icon">
                        <i class="fas fa-folder-open"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Study Resources</h3>
                        <p class="card-subtitle">Access learning materials</p>
                    </div>
                </div>
                <div class="card-content">
                    <p>Access study materials, practice tests, reference books, and additional learning resources shared
                        by your tutors.</p>
                </div>
                <div class="card-actions">
                    <span class="btn btn-primary">
                        <i class="fas fa-folder-open"></i> View Resources
                    </span>
                    <span class="btn btn-secondary">
                        <i class="fas fa-download"></i> Download All
                    </span>
                </div>
            </a>
        </div>

        <!-- Recent Activity Section -->
        <div class="recent-activity">
            <h2 class="section-title">
                <i class="fas fa-history"></i>
                Recent Activity
            </h2>

            <ul class="activity-list">
                <?php if (count($recentItems) === 0): ?>
                    <li class="activity-item">
                        <div class="activity-icon">
                            <i class="fas fa-info-circle"></i>
                        </div>
                        <div class="activity-details">
                            <div class="activity-title">No recent activity found yet</div>
                            <div class="activity-time">When you receive messages or resources, they will appear here.</div>
                        </div>
                    </li>
                <?php else: ?>
                    <?php foreach ($recentItems as $it): ?>
                        <li class="activity-item">
                            <div class="activity-icon">
                                <?php if ($it["type"] === "message"): ?>
                                    <i class="fas fa-envelope"></i>
                                <?php else: ?>
                                    <i class="fas fa-folder-plus"></i>
                                <?php endif; ?>
                            </div>
                            <div class="activity-details">
                                <div class="activity-title"><?= htmlspecialchars($it["title"]) ?></div>
                                <div class="activity-time"><?= htmlspecialchars(nice_time((int)$it["time"])) ?></div>
                            </div>
                        </li>
                    <?php endforeach; ?>
                <?php endif; ?>
            </ul>
        </div>
    </main>

    <!-- Notification -->
    <div class="notification" id="notification">
        <div id="notificationMessage">Operation completed successfully!</div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            setActiveNav();

            const cards = document.querySelectorAll('.dashboard-card');
            cards.forEach(card => {
                card.addEventListener('mouseenter', function () {
                    this.style.transform = 'translateY(-5px)';
                });

                card.addEventListener('mouseleave', function () {
                    this.style.transform = 'translateY(0)';
                });
            });
        });

        function setActiveNav() {
            const currentPage = window.location.pathname.split('/').pop();
            document.querySelectorAll('.nav-links a').forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === currentPage) {
                    link.classList.add('active');
                }
            });
        }

        function logout() {
            if (confirm('Are you sure you want to logout?')) {
                window.location.href = '../auth/logout.php';
            }
        }
    </script>
</body>

</html>
