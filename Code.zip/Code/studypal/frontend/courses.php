<?php
session_start();
$isLoggedIn = isset($_SESSION['user_id']) || (isset($_SESSION['isLoggedIn']) && $_SESSION['isLoggedIn'] === true);
$userName = $_SESSION['full_name'] ?? '';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>StudyPals — Find a Tutor</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="assets/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Main Layout */
        .main-content {
            display: flex;
            gap: 30px;
            padding: 30px 0;
        }

        /* Filters Sidebar */
        .filters-sidebar {
            width: 280px;
            flex-shrink: 0;
        }

        .filters-card {
            background: white;
            border-radius: 10px;
            padding: 24px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            margin-bottom: 20px;
        }

        .filters-card h3 {
            font-size: 18px;
            margin-bottom: 20px;
            color: #000000;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }

        .filter-section {
            margin-bottom: 24px;
        }

        .filter-section h4 {
            font-size: 16px;
            margin-bottom: 12px;
            color: #000000;
        }

        .input,
        select {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
            background: white;
            margin-bottom: 8px;
            color: #000000;
        }

        .input:focus,
        select:focus {
            outline: none;
            border-color: #2d6ae3;
        }

        .input::placeholder {
            color: #666666;
        }

        .checkbox-group {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .checkbox-item {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .checkbox-item input {
            width: 18px;
            height: 18px;
        }

        .checkbox-item label {
            font-size: 15px;
            color: #000000;
        }

        /* Results Section */
        .results-section {
            flex: 1;
        }

        .results-header {
            margin-bottom: 24px;
            padding: 0 0 16px 0;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        .results-header h1 {
            font-size: 28px;
            color: #f6f0f0;
            margin-bottom: 8px;
        }

        .results-count {
            color: #fcfcfc;
            font-size: 15px;
            flex: 1;
        }

        .sort-options {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .sort-options select {
            width: 200px;
            margin-bottom: 0;
            color: #000000;
        }

        .sort-options select option {
            color: #000000;
        }

        /* Tutor Cards */
        .tutor-cards {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .tutor-card {
            background: white;
            border-radius: 10px;
            padding: 24px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            display: flex;
            gap: 20px;
            transition: transform 0.3s, box-shadow 0.3s;
            position: relative;
            overflow: hidden;
        }

        .tutor-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
        }

        .tutor-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background-color: #eef4ff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            color: #2d6ae3;
            font-weight: 600;
            flex-shrink: 0;
            overflow: hidden;
        }

        .tutor-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .tutor-info {
            flex: 1;
        }

        .tutor-name {
            font-size: 20px;
            font-weight: 600;
            color: #000000;
            margin-bottom: 4px;
        }

        .tutor-subjects {
            font-size: 14px;
            color: #2d6ae3;
            background: #eef4ff;
            padding: 4px 10px;
            border-radius: 20px;
            display: inline-block;
            margin-bottom: 12px;
        }

        .tutor-bio {
            color: #000000;
            font-size: 15px;
            line-height: 1.5;
            margin-bottom: 16px;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .tutor-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }

        .tutor-rating {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 15px;
            color: #000000;
        }

        .stars {
            color: #ffc107;
            font-weight: bold;
        }

        .tutor-pricing {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .tutor-price {
            font-size: 18px;
            font-weight: 700;
            color: #2d6ae3;
            position: relative;
            padding: 8px 16px;
            background: linear-gradient(135deg, #eef4ff, #d9e4ff);
            border-radius: 30px;
            animation: priceBubble 2s infinite alternate;
            box-shadow: 0 4px 8px rgba(45, 106, 227, 0.2);
        }

        @keyframes priceBubble {
            0% {
                transform: translateY(0);
                box-shadow: 0 4px 8px rgba(45, 106, 227, 0.2);
            }
            100% {
                transform: translateY(-3px);
                box-shadow: 0 6px 12px rgba(45, 106, 227, 0.3);
            }
        }

        .tutor-actions {
            display: flex;
            gap: 10px;
        }

        .btn {
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            border: none;
            font-size: 15px;
            transition: all 0.2s;
        }

        .btn-outline {
            background: white;
            border: 1px solid #2d6ae3;
            color: #2d6ae3;
        }

        .btn-outline:hover {
            background: #f5f8ff;
            transform: scale(1.05);
        }

        .btn-primary {
            background: #2d6ae3;
            color: white;
        }

        .btn-primary:hover {
            background: #1a56d9;
            transform: scale(1.05);
        }

        /* Help Section */
        .help-section {
            background: #f0f7ff;
            border-radius: 10px;
            padding: 24px;
            margin-top: 30px;
            border: 1px solid #c2d4ff;
        }

        .help-section h3 {
            color: #2d6ae3;
            margin-bottom: 16px;
            font-size: 18px;
        }

        .help-section p {
            color: #000000;
            margin-bottom: 16px;
        }

        .help-btn {
            background: white;
            color: #2d6ae3;
            border: 1px solid #2d6ae3;
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        /* Filter Results Display */
        .active-filters {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
            border-left: 4px solid #2d6ae3;
            animation: slideIn 0.5s ease-out;
        }

        .filter-tag {
            background: #eef4ff;
            color: #2d6ae3;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .filter-tag i {
            cursor: pointer;
            font-size: 12px;
        }

        /* Profile Modal */
        .profile-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .profile-modal.active {
            display: flex;
        }

        .modal-content {
            background: white;
            border-radius: 15px;
            width: 100%;
            max-width: 900px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        }

        .modal-header {
            padding: 30px;
            border-bottom: 1px solid #eee;
            background: linear-gradient(135deg, #2d6ae3, #1a56d9);
            color: white;
            border-radius: 15px 15px 0 0;
            display: flex;
            align-items: center;
            gap: 20px;
            position: relative;
        }

        .modal-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            border: 4px solid white;
            overflow: hidden;
            background: #eef4ff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
            color: #2d6ae3;
            font-weight: 600;
        }

        .modal-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .modal-header-info {
            flex: 1;
        }

        .modal-name {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 8px;
            color: white;
        }

        .modal-subjects {
            font-size: 18px;
            opacity: 0.9;
            margin-bottom: 15px;
            color: white;
        }

        .modal-price-large {
            font-size: 24px;
            background: rgba(255, 255, 255, 0.2);
            padding: 10px 20px;
            border-radius: 30px;
            display: inline-block;
            color: white;
        }

        .modal-body {
            padding: 30px;
        }

        .modal-section {
            margin-bottom: 30px;
        }

        .modal-section h3 {
            color: #000000;
            font-size: 20px;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #eef4ff;
        }

        .modal-bio {
            line-height: 1.7;
            color: #000000;
            font-size: 16px;
        }

        .close-modal {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            font-size: 24px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }

        .page-btn {
            padding: 8px 16px;
            border: 1px solid #ddd;
            background: white;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.2s;
            color: #000000;
        }

        .page-btn.active {
            background: #2d6ae3;
            color: white;
            border-color: #2d6ae3;
        }

        /* Responsive */
        @media (max-width: 900px) {
            .main-content {
                flex-direction: column;
            }
            .filters-sidebar {
                width: 100%;
            }
            .tutor-card {
                flex-direction: column;
                align-items: center;
                text-align: center;
            }
        }
    </style>
</head>

<body>
<header class="nav">
    <div class="container">
        <div class="brand">StudyPals</div>

        <!-- NAVBAR: only changed to PHP session-aware, layout unchanged -->
        <nav class="nav-links">
            <a href="index.html">Home</a>
            <a href="courses.php">Courses</a>
            <a href="about.html">About / Contact</a>

            <?php if ($isLoggedIn): ?>
                <a href="#" style="pointer-events:none;opacity:.9;"><?= htmlspecialchars($userName) ?></a>
                <a href="/studypal/auth/logout.php">Logout</a>
            <?php else: ?>
                <a href="/studypal/frontend/login.html">Login</a>
                <a href="/studypal/auth/register_student.php">Sign Up</a>
            <?php endif; ?>
        </nav>
    </div>
</header>

<main class="container main-content">
    <!-- Filters Sidebar -->
    <aside class="filters-sidebar">
        <div class="filters-card">
            <h3>Filters</h3>

            <div class="filter-section">
                <h4>Subject</h4>
                <select class="input subject-filter">
                    <option value="">All Subjects</option>
                    <option value="math">Math</option>
                    <option value="english">English</option>
                    <option value="chemistry">Chemistry</option>
                    <option value="biology">Biology</option>
                    <option value="physics">Physics</option>
                    <option value="history">History</option>
                    <option value="geography">Geography</option>
                    <option value="computer science">Computer Science</option>
                    <option value="spanish">Spanish</option>
                    <option value="french">French</option>
                </select>
            </div>

            <div class="filter-section">
                <h4>Level</h4>
                <select class="input level-filter">
                    <option value="">All Levels</option>
                    <option value="ks3">KS3</option>
                    <option value="gcse">GCSE</option>
                    <option value="a-levels">A-Levels</option>
                    <option value="university">University</option>
                </select>
            </div>

            <!-- Curriculum removed (as requested) -->
        </div>

        <div class="filters-card">
            <div class="filter-section">
                <h4>Startup price</h4>
                <div class="price-range">
                    <select class="input price-filter">
                        <option value="">All Prices</option>
                        <option value="0-30">£0 - £30</option>
                        <option value="31-50">£31 - £50</option>
                        <option value="51-80">£51 - £80</option>
                        <option value="81-120">£81 - £120</option>
                        <option value="121-200">£121 - £200</option>
                    </select>
                </div>
            </div>

            <div class="filter-section">
                <h4>Qualification</h4>
                <div class="checkbox-group">
                    <div class="checkbox-item">
                        <input type="checkbox" id="qualified" class="qualified-filter" checked>
                        <label for="qualified">Only show qualified teachers in search results</label>
                    </div>
                </div>
            </div>

            <div class="filter-section">
                <h4>Special needs</h4>
                <div class="checkbox-group">
                    <div class="checkbox-item">
                        <input type="checkbox" id="specialNeeds" class="specialneeds-filter">
                        <label for="specialNeeds">Only show tutors who have experience with special needs</label>
                    </div>
                </div>
            </div>
        </div>
    </aside>

    <!-- Results Section -->
    <section class="results-section">
        <div class="results-header">
            <div>
                <h1>Find a tutor</h1>
                <div class="results-count" id="resultsCount">Showing 20 of 100 tutors</div>
            </div>
            <div class="sort-options">
                <select class="input sort-filter" id="sortFilter">
                    <option value="default">Sort by: Default</option>
                    <option value="price-low-high">Price: Low to High</option>
                    <option value="price-high-low">Price: High to Low</option>
                    <option value="popularity">Most Popular</option>
                    <option value="rating">Highest Rating</option>
                </select>
            </div>
        </div>

        <div class="active-filters" id="activeFilters" style="display:none;"></div>

        <div class="tutor-cards" id="tutorCards"></div>

        <div class="pagination" id="pagination">
            <button class="page-btn" id="prevPage">← Previous</button>
            <div id="pageNumbers"></div>
            <button class="page-btn" id="nextPage">Next →</button>
        </div>

        <div class="help-section">
            <h3>Need help finding a tutor?</h3>
            <p>Let us know what kind of tutor you're looking for. Chat with Learmate and get personalized recommendations.</p>
            <button class="help-btn">Get Help Finding a Tutor</button>
        </div>
    </section>
</main>

<!-- Profile Modal -->
<div class="profile-modal" id="profileModal">
    <div class="modal-content">
        <div class="modal-header">
            <button class="close-modal" id="closeModal">×</button>
            <div class="modal-avatar" id="modalAvatar"></div>
            <div class="modal-header-info">
                <h2 class="modal-name" id="modalName"></h2>
                <div class="modal-subjects" id="modalSubjects"></div>
                <div class="modal-price-large" id="modalPrice"></div>
            </div>
        </div>
        <div class="modal-body">
            <div class="modal-section">
                <h3>About Me</h3>
                <p class="modal-bio" id="modalBio"></p>
            </div>
            <div class="modal-section">
                <h3>Teaching Experience</h3>
                <p class="modal-bio" id="modalExperience"></p>
            </div>
        </div>
    </div>
</div>

<script>
    // Session flag from PHP (no DB)
    const IS_LOGGED_IN = <?= $isLoggedIn ? 'true' : 'false' ?>;

    const generateTutors = () => {
        const tutors = [];
        const subjects = ['Math', 'English', 'Chemistry', 'Biology', 'Physics', 'History', 'Geography', 'Computer Science', 'Spanish', 'French'];
        const levels = ['ks3', 'gcse', 'a-levels', 'university'];
        const firstNames = ['James','Emma','Liam','Olivia','Noah','Ava','Oliver','Isabella','Elijah','Sophia','William','Charlotte','Benjamin','Mia','Lucas','Amelia','Henry','Harper','Alexander','Evelyn'];
        const lastNames = ['Smith','Johnson','Williams','Brown','Jones','Garcia','Miller','Davis','Rodriguez','Martinez','Hernandez','Lopez','Gonzalez','Wilson','Anderson','Thomas','Taylor','Moore','Jackson','Martin'];

        const detailedBios = [
            "I'm a passionate educator with over 8 years of experience specialising in making complex concepts accessible to students of all abilities. My teaching philosophy centers on building confidence and fostering a love for learning through interactive, student-centered lessons.",
            "As a specialist tutor, I bring a creative approach with years of classroom and tutoring experience. I focus on developing exam technique and deep understanding, helping students improve grades and confidence.",
            "With an academic background and professional experience, I offer clear explanations and targeted practice. My sessions are structured, friendly, and tailored to your learning style.",
            "I focus on fast progress through smart diagnostics, personalised revision plans, and confidence-building strategies. Ideal for students who want clear structure and measurable improvement."
        ];

        const experience = [
            "10+ years teaching experience with specialist training in differentiated instruction.",
            "Former head of department, now specialising in individualised tutoring programs.",
            "Extensive experience supporting exam preparation and anxiety management.",
            "Proven track record: most students improve 1–3 grades within one term."
        ];

        for (let i = 1; i <= 100; i++) {
            const subject = subjects[Math.floor(Math.random() * subjects.length)];
            const level = levels[Math.floor(Math.random() * levels.length)];
            const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
            const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
            const price = Math.floor(Math.random() * 150) + 20;
            const reviews = Math.floor(Math.random() * 100) + 5;
            const rating = (Math.random() * 1 + 4).toFixed(1);
            const qualified = Math.random() > 0.3;
            const specialneeds = Math.random() > 0.5;
            const gender = Math.random() > 0.5 ? 'men' : 'women';
            const avatarNumber = Math.floor(Math.random() * 80) + 1;

            tutors.push({
                id: i,
                name: `${firstName} ${lastName}`,
                firstName,
                avatar: `https://randomuser.me/api/portraits/${gender}/${avatarNumber}.jpg`,
                subjects: `${subject} • ${level.toUpperCase()}`,
                price: `£${price}`,
                level,
                bio: detailedBios[Math.floor(Math.random() * detailedBios.length)],
                experience: experience[Math.floor(Math.random() * experience.length)],
                email: `${firstName.toLowerCase()}.${lastName.toLowerCase()}@studypals.com`,
                phone: `+44 7${Math.floor(100 + Math.random() * 900)} ${Math.floor(100000 + Math.random() * 900000)}`,
                responseTime: `${Math.floor(1 + Math.random() * 12)} hours`,
                rating: `${rating} (${reviews} reviews)`,
                qualified,
                specialneeds,
                popularity: Math.floor(Math.random() * 1000),
                priceValue: price,
                ratingValue: parseFloat(rating),
                subjectCategory: subject.toLowerCase()
            });
        }
        return tutors;
    };

    const allTutors = generateTutors();
    let filteredTutors = [...allTutors];
    let currentPage = 1;
    const tutorsPerPage = 20;

    const subjectFilter = document.querySelector('.subject-filter');
    const levelFilter = document.querySelector('.level-filter');
    const priceFilter = document.querySelector('.price-filter');
    const qualifiedFilter = document.querySelector('.qualified-filter');
    const specialNeedsFilter = document.querySelector('.specialneeds-filter');
    const sortFilter = document.getElementById('sortFilter');

    const activeFiltersContainer = document.getElementById('activeFilters');
    const tutorCardsContainer = document.getElementById('tutorCards');
    const resultsCount = document.getElementById('resultsCount');
    const prevPageBtn = document.getElementById('prevPage');
    const nextPageBtn = document.getElementById('nextPage');
    const pageNumbersContainer = document.getElementById('pageNumbers');

    let activeFilters = {
        subject: '',
        level: '',
        price: '',
        qualified: true,
        specialneeds: false,
        sort: 'default'
    };

    subjectFilter.addEventListener('change', function() {
        activeFilters.subject = this.value;
        currentPage = 1;
        updateActiveFilters();
        filterTutors();
    });

    levelFilter.addEventListener('change', function() {
        activeFilters.level = this.value;
        currentPage = 1;
        updateActiveFilters();
        filterTutors();
    });

    priceFilter.addEventListener('change', function() {
        activeFilters.price = this.value;
        currentPage = 1;
        updateActiveFilters();
        filterTutors();
    });

    qualifiedFilter.addEventListener('change', function() {
        activeFilters.qualified = this.checked;
        currentPage = 1;
        updateActiveFilters();
        filterTutors();
    });

    specialNeedsFilter.addEventListener('change', function() {
        activeFilters.specialneeds = this.checked;
        currentPage = 1;
        updateActiveFilters();
        filterTutors();
    });

    sortFilter.addEventListener('change', function() {
        activeFilters.sort = this.value;
        currentPage = 1;
        updateActiveFilters();
        filterTutors();
    });

    function filterTutors() {
        filteredTutors = allTutors.filter(tutor => {
            if (activeFilters.subject && tutor.subjectCategory !== activeFilters.subject) return false;
            if (activeFilters.level && tutor.level !== activeFilters.level) return false;

            if (activeFilters.price) {
                const [min, max] = activeFilters.price.split('-').map(p => parseInt(p.trim(), 10));
                if (tutor.priceValue < min || tutor.priceValue > max) return false;
            }

            if (activeFilters.qualified && !tutor.qualified) return false;
            if (activeFilters.specialneeds && !tutor.specialneeds) return false;

            return true;
        });

        applySorting();
        updateResults();
    }

    function applySorting() {
        switch(activeFilters.sort) {
            case 'price-low-high':
                filteredTutors.sort((a, b) => a.priceValue - b.priceValue);
                break;
            case 'price-high-low':
                filteredTutors.sort((a, b) => b.priceValue - a.priceValue);
                break;
            case 'rating':
                filteredTutors.sort((a, b) => b.ratingValue - a.ratingValue);
                break;
            default:
                filteredTutors.sort((a, b) => a.id - b.id);
        }
    }

    function updateResults() {
        const startIndex = (currentPage - 1) * tutorsPerPage;
        const endIndex = startIndex + tutorsPerPage;
        const pageTutors = filteredTutors.slice(startIndex, endIndex);

        tutorCardsContainer.innerHTML = '';

        pageTutors.forEach(tutor => {
            const tutorCard = document.createElement('div');
            tutorCard.className = 'tutor-card';

            tutorCard.innerHTML = `
                <div class="tutor-avatar">
                    <img src="${tutor.avatar}" alt="${tutor.name}">
                </div>
                <div class="tutor-info">
                    <h3 class="tutor-name">${tutor.name}</h3>
                    <div class="tutor-subjects">${tutor.subjects}</div>
                    <p class="tutor-bio">${tutor.bio}</p>
                    <div class="tutor-footer">
                        <div class="tutor-rating">
                            <span class="stars">★★★★★</span>
                            <span>${tutor.rating}</span>
                        </div>
                        <div class="tutor-pricing">
                            <span class="tutor-price">From ${tutor.price}</span>
                            <div class="tutor-actions">
                                <button class="btn btn-outline view-profile" data-tutor="${tutor.id}">View profile</button>
                                <button class="btn btn-primary enroll-btn" data-tutor="${tutor.id}">Enroll</button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            tutorCardsContainer.appendChild(tutorCard);
        });

        document.querySelectorAll('.view-profile').forEach(button => {
            button.addEventListener('click', function() {
                const tutorId = parseInt(this.getAttribute('data-tutor'), 10);
                openProfileModal(tutorId);
            });
        });

        document.querySelectorAll('.enroll-btn').forEach(button => {
            button.addEventListener('click', function() {
                enrollTutor(this.getAttribute('data-tutor'));
            });
        });

        const totalTutors = filteredTutors.length;
        const showingStart = Math.min(startIndex + 1, totalTutors);
        const showingEnd = Math.min(endIndex, totalTutors);

        resultsCount.textContent = totalTutors === 0
            ? 'No tutors found'
            : `Showing ${showingStart}-${showingEnd} of ${totalTutors} tutors`;

        updatePagination();
    }

    function updatePagination() {
        const totalPages = Math.ceil(filteredTutors.length / tutorsPerPage);
        prevPageBtn.disabled = currentPage === 1;
        nextPageBtn.disabled = currentPage === totalPages;

        pageNumbersContainer.innerHTML = '';

        for (let i = 1; i <= Math.min(totalPages, 5); i++) {
            const pageBtn = document.createElement('button');
            pageBtn.className = `page-btn ${i === currentPage ? 'active' : ''}`;
            pageBtn.textContent = i;
            pageBtn.addEventListener('click', () => {
                currentPage = i;
                updateResults();
            });
            pageNumbersContainer.appendChild(pageBtn);
        }
    }

    prevPageBtn.addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage--;
            updateResults();
        }
    });

    nextPageBtn.addEventListener('click', () => {
        const totalPages = Math.ceil(filteredTutors.length / tutorsPerPage);
        if (currentPage < totalPages) {
            currentPage++;
            updateResults();
        }
    });

    function updateActiveFilters() {
        const tags = [];
        if (activeFilters.subject) tags.push({ key: 'subject', label: `Subject: ${activeFilters.subject}`});
        if (activeFilters.level) tags.push({ key: 'level', label: `Level: ${activeFilters.level.toUpperCase()}`});
        if (activeFilters.price) tags.push({ key: 'price', label: `Price: £${activeFilters.price.replace('-', ' - ')}`});
        if (!activeFilters.qualified) tags.push({ key: 'qualified', label: 'Including unqualified' });
        if (activeFilters.specialneeds) tags.push({ key: 'specialneeds', label: 'Special Needs Experience' });

        if (tags.length === 0) {
            activeFiltersContainer.style.display = 'none';
            return;
        }

        activeFiltersContainer.style.display = 'flex';
        activeFiltersContainer.innerHTML = tags.map(t => `
            <div class="filter-tag">
                ${t.label}
                <i class="fas fa-times" onclick="removeFilter('${t.key}')"></i>
            </div>
        `).join('');
    }

    window.removeFilter = function(key) {
        if (key === 'subject') { activeFilters.subject=''; subjectFilter.value=''; }
        if (key === 'level') { activeFilters.level=''; levelFilter.value=''; }
        if (key === 'price') { activeFilters.price=''; priceFilter.value=''; }
        if (key === 'qualified') { activeFilters.qualified=true; qualifiedFilter.checked=true; }
        if (key === 'specialneeds') { activeFilters.specialneeds=false; specialNeedsFilter.checked=false; }
        currentPage = 1;
        updateActiveFilters();
        filterTutors();
    };

    function openProfileModal(tutorId) {
        const tutor = allTutors.find(t => t.id === Number(tutorId));
        if (!tutor) return;

        document.getElementById('modalName').textContent = tutor.name;
        document.getElementById('modalSubjects').textContent = tutor.subjects;
        document.getElementById('modalPrice').textContent = `From ${tutor.price}`;
        document.getElementById('modalBio').textContent = tutor.bio;
        document.getElementById('modalExperience').textContent = tutor.experience;

        document.getElementById('modalAvatar').innerHTML = `<img src="${tutor.avatar}" alt="${tutor.name}">`;

        document.getElementById('profileModal').classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeProfileModal() {
        document.getElementById('profileModal').classList.remove('active');
        document.body.style.overflow = 'auto';
    }

    document.getElementById('closeModal').addEventListener('click', closeProfileModal);
    document.getElementById('profileModal').addEventListener('click', function(e) {
        if (e.target === this) closeProfileModal();
    });

    function enrollTutor(tutorId) {
        if (!IS_LOGGED_IN) {
            alert("Please log in to enroll with a tutor.");
            window.location.href = "/studypal/frontend/login.html";
            return;
        }
        alert("Enroll clicked for tutor #" + tutorId + ". Enrollment DB flow will be connected next.");
    }

    // init
    filterTutors();
</script>

</body>
</html>
