<?php
session_start();
require_once __DIR__ . "/../includes/db_connect.php";

if (!isset($_SESSION['isLoggedIn']) || ($_SESSION['role'] ?? '') !== 'tutor') {
    header("Location: /studypal/frontend/login.html");
    exit;
}

/* Does tutor have real students? */
$stmt = $pdo->prepare("
    SELECT COUNT(*) 
    FROM tutor_profiles tp
    JOIN courses c ON c.tutor_id = tp.id
    JOIN enrollments e ON e.course_id = c.id
    WHERE tp.user_id = ? AND e.status='approved'
");
$stmt->execute([$_SESSION['user_id']]);
$hasRealMessages = $stmt->fetchColumn() > 0;

include __DIR__ . "/tutor_messages.html";
?>

<script>
function logout(){ window.location.href="/studypal/auth/logout.php"; }

document.addEventListener('DOMContentLoaded', () => {
  const REAL = <?= $hasRealMessages ? 'true' : 'false' ?>;
  if (!REAL) return; // demo chat remains demo

  // Override message system with DB-backed messaging
  fetch("/studypal/api/tutor_contacts.php")
    .then(r=>r.json())
    .then(d=>{
      window.contacts = d.contacts;
      window.messages = {};
      loadContacts();
      if (contacts.length) openContact(contacts[0]);
    });
});
</script>
