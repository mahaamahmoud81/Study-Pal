<?php
session_start();
require_once "../includes/db_connect.php";

if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "parent") {
    header("Location: ../auth/login.php");
    exit;
}

$parentId = $_SESSION["user_id"];

/* Parent name */
$stmt = $pdo->prepare("SELECT full_name FROM users WHERE id = ?");
$stmt->execute([$parentId]);
$parentName = $stmt->fetchColumn();

/* Children count */
$stmt = $pdo->prepare("SELECT COUNT(*) FROM parent_child WHERE parent_id = ?");
$stmt->execute([$parentId]);
$childrenCount = (int)$stmt->fetchColumn();

/* Active courses (via child enrollments) */
$stmt = $pdo->prepare("
    SELECT COUNT(DISTINCT e.course_id)
    FROM parent_child pc
    JOIN enrollments e ON e.student_id = pc.student_id
    WHERE pc.parent_id = ?
");
$stmt->execute([$parentId]);
$activeCourses = (int)$stmt->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StudyPals — Parent Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --accent: #3b82f6;
            --accent-dark: #2563eb;
            --accent-light: #60a5fa;
            --accent-hover: rgba(59, 130, 246, 0.1);
            --accent-active: rgba(59, 130, 246, 0.2);
            --bg: #0f172a;
            --card: #1e293b;
            --card-hover: #334155;
            --text: #f1f5f9;
            --text-muted: #94a3b8;
            --border: #334155;
            --success: #34d399;
            --danger: #f87171;
            --warning: #fbbf24;
            --purple: #8b5cf6;
            --pink: #ec4899;
            --orange: #f59e0b;
            --cyan: #06b6d4;
            --radius: 16px;
            --radius-sm: 8px;
            --shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
        }

        body {
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
            overflow-x: hidden;
        }

        .nav {
            background: var(--card);
            border-bottom: 1px solid var(--border);
            padding: 0 24px;
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 0;
        }

        .brand {
            font-size: 28px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--accent), var(--accent-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
        }

        .nav-links {
            display: flex;
            gap: 24px;
            align-items: center;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--text-muted);
            font-weight: 500;
            padding: 10px 16px;
            border-radius: var(--radius-sm);
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .nav-links a:hover {
            color: var(--text);
            background: var(--accent-hover);
        }

        .nav-links a.active {
            color: var(--accent);
            background: var(--accent-active);
        }

        .profile-dropdown {
            position: relative;
        }

        .profile-btn {
            background: none;
            border: none;
            color: var(--text);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            border-radius: var(--radius-sm);
            transition: var(--transition);
        }

        .profile-btn:hover {
            background: var(--accent-hover);
        }

        .profile-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--accent), var(--accent-dark));
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }

        .dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            min-width: 200px;
            box-shadow: var(--shadow);
            display: none;
            z-index: 1000;
        }

        .profile-dropdown:hover .dropdown-menu,
        .profile-dropdown:focus-within .dropdown-menu {
            display: block;
        }

        .dropdown-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: var(--text);
            text-decoration: none;
            transition: var(--transition);
            border-bottom: 1px solid var(--border);
        }

        .dropdown-item:last-child {
            border-bottom: none;
        }

        .dropdown-item:hover {
            background: var(--accent-hover);
            color: var(--accent);
        }

        .dropdown-item.logout {
            color: var(--danger);
        }

        .dropdown-item.logout:hover {
            background: rgba(248, 113, 113, 0.1);
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 40px 24px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--border);
        }

        .page-title {
            font-size: 2rem;
            font-weight: 700;
            color: var(--text);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: var(--radius-sm);
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--accent), var(--accent-dark));
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.3);
        }

        .btn-secondary {
            background: transparent;
            border: 2px solid var(--accent);
            color: var(--accent);
        }

        .btn-secondary:hover {
            background: var(--accent-hover);
            transform: translateY(-2px);
        }

        .btn-danger {
            background: var(--danger);
            color: white;
        }

        .btn-danger:hover {
            background: #dc2626;
            transform: translateY(-2px);
        }

        /* Welcome Section */
        .welcome-section {
            background: var(--card);
            border-radius: var(--radius);
            padding: 40px;
            border: 1px solid var(--border);
            margin-bottom: 40px;
            position: relative;
            overflow: hidden;
        }

        .welcome-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--accent), var(--accent-dark));
        }

        .welcome-content h1 {
            font-size: 2.5rem;
            margin-bottom: 8px;
            background: linear-gradient(135deg, var(--text), var(--accent-light));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .welcome-content p {
            color: var(--text-muted);
            font-size: 1.1rem;
            margin-bottom: 24px;
        }

        .parent-stats {
            display: flex;
            gap: 32px;
            margin-top: 32px;
            flex-wrap: wrap;
        }

        .stat-badge {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
            padding: 16px 24px;
            background: rgba(15, 23, 42, 0.5);
            border-radius: var(--radius);
            border: 1px solid var(--border);
            min-width: 120px;
            cursor: pointer;
            transition: var(--transition);
        }

        .stat-badge:hover {
            border-color: var(--accent);
            transform: translateY(-2px);
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--accent);
        }

        .stat-label {
            font-size: 0.9rem;
            color: var(--text-muted);
            text-align: center;
        }

        /* Dashboard Grid */
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }

        .dashboard-card {
            background: var(--card);
            border-radius: var(--radius);
            padding: 30px;
            border: 1px solid var(--border);
            transition: var(--transition);
            cursor: pointer;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow);
            border-color: var(--accent);
        }

        .card-header {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 20px;
        }

        .card-icon {
            width: 56px;
            height: 56px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        .card-blue .card-icon {
            background: linear-gradient(135deg, var(--accent), var(--accent-dark));
            color: white;
        }

        .card-green .card-icon {
            background: linear-gradient(135deg, var(--success), #10b981);
            color: white;
        }

        .card-purple .card-icon {
            background: linear-gradient(135deg, var(--purple), #7c3aed);
            color: white;
        }

        .card-pink .card-icon {
            background: linear-gradient(135deg, var(--pink), #db2777);
            color: white;
        }

        .card-orange .card-icon {
            background: linear-gradient(135deg, var(--orange), #d97706);
            color: white;
        }

        .card-cyan .card-icon {
            background: linear-gradient(135deg, var(--cyan), #0891b2);
            color: white;
        }

        .card-title {
            font-size: 1.4rem;
            font-weight: 600;
            color: var(--text);
            margin-bottom: 4px;
        }

        .card-subtitle {
            color: var(--text-muted);
            font-size: 0.9rem;
        }

        .card-content {
            margin-bottom: 24px;
            line-height: 1.6;
            flex: 1;
        }

        .card-actions {
            display: flex;
            gap: 12px;
            margin-top: auto;
        }

        /* Notification */
        .notification {
            position: fixed;
            top: 100px;
            right: 30px;
            padding: 16px 24px;
            background: var(--card);
            border-radius: var(--radius-sm);
            border-left: 4px solid var(--accent);
            box-shadow: var(--shadow);
            z-index: 10000;
            transform: translateX(400px);
            transition: transform 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            max-width: 400px;
        }

        .notification.active {
            transform: translateX(0);
        }

        .notification-success {
            border-left-color: var(--success);
        }

        .notification-error {
            border-left-color: var(--danger);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .nav-links a:not(.active) {
                display: none;
            }

            .parent-stats {
                flex-wrap: wrap;
                justify-content: center;
                gap: 20px;
            }

            .stat-badge {
                min-width: 100px;
                padding: 12px 16px;
            }

            .container {
                padding: 20px 16px;
            }

            .welcome-section {
                padding: 24px;
            }

            .dashboard-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>
    <!-- Navigation -->
    <header class="nav">
        <div class="nav-container">
            <div class="brand" onclick="window.location.href='parent_dashboard.html'">
                <i class="fas fa-graduation-cap"></i>
                StudyPals
            </div>
            <nav class="nav-links">
                <a href="parent_home_profile.html" class="active">
                    <i class="fas fa-home"></i> Home
                </a>
                <a href="parent_child_progress.html">
                    <i class="fas fa-chart-line"></i> Child Progress
                </a>
                <a href="parent_messages.html">
                    <i class="fas fa-messages"></i> Messages
                </a>
                <a href="parent_sessions.html">
                    <i class="fas fa-calendar-alt"></i> Sessions

                    <a href="parent_resources.html">
                        <i class="fas fa-folder-open"></i> Resources

                        <div class="profile-dropdown">
                            <button class="profile-btn">
                                <div class="profile-avatar">RJ</div>
                                <i class="fas fa-chevron-down"></i>
                            </button>
                            <div class="dropdown-menu">
                                <a href="parent_profile.html" class="dropdown-item">
                                    <i class="fas fa-user"></i> My Account
                                </a>
                                <a href="parent_settings.html" class="dropdown-item">
                                    <i class="fas fa-cog"></i> Settings
                                </a>
                                <a href="#" class="dropdown-item" onclick="logout()">
                                    <i class="fas fa-sign-out-alt"></i> Logout
                                </a>
                            </div>
                        </div>
            </nav>
        </div>
    </header>

    <!-- Main Content -->
    <main class="container">
        <!-- Welcome Section -->
        <div class="welcome-section">
            <div class="welcome-content">
                <h1>Welcome back, <?= htmlspecialchars($parentName) ?>!</h1>
                <p>Track your child's progress, communicate with tutors, and manage learning journey</p>
                <div class="parent-stats">
                    <div class="stat-badge" onclick="window.location.href='parent_child_progress.html'">
                        <span class="stat-value" id="totalChildren"><?= $childrenCount ?></span>
                        <span class="stat-label">Children</span>
                    </div>
                    <div class="stat-badge" onclick="window.location.href='parent_child_progress.html'">
                        <span class="stat-value" id="activeCourses"><?= $activeCourses ?></span>
                        <span class="stat-label">Active Courses</span>
                    </div>
                    <div class="stat-badge" onclick="window.location.href='parent_child_progress.html'">
                        <span class="stat-value" id="avgGrade">B+</span>
                        <span class="stat-label">Average Grade</span>
                    </div>
                    <div class="stat-badge" onclick="window.location.href='parent_sessions.html'">
                        <span class="stat-value" id="upcomingSessions">3</span>
                        <span class="stat-label">Upcoming Sessions</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Dashboard Grid -->
        <div class="dashboard-grid">
            <!-- Child Progress -->
            <div class="dashboard-card card-blue">
                <div class="card-header">
                    <div class="card-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Child Progress</h3>
                        <p class="card-subtitle">Track academic performance</p>
                    </div>
                </div>
                <div class="card-content">
                    <p>Monitor your child's grades, attendance, and overall academic performance across all subjects.
                    </p>
                </div>
                <div class="card-actions">
                    <button class="btn btn-primary" onclick="window.location.href='parent_child_progress.html'">
                        <i class="fas fa-eye"></i> View Progress
                    </button>
                    <button class="btn btn-secondary" onclick="downloadReport()">
                        <i class="fas fa-download"></i> Download Report
                    </button>
                </div>
            </div>

            <!-- Messages -->
            <div class="dashboard-card card-blue">
                <div class="card-header">
                    <div class="card-icon">
                        <i class="fas fa-messages"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Messages</h3>
                        <p class="card-subtitle">Communicate with tutors</p>
                    </div>
                </div>
                <div class="card-content">
                    <p>Message your child's tutors, ask questions about progress, and stay updated on their learning.
                    </p>
                </div>
                <div class="card-actions">
                    <button class="btn btn-primary" onclick="window.location.href='parent_messages.html'">
                        <i class="fas fa-envelope"></i> View Messages
                    </button>
                    <button class="btn btn-secondary" onclick="window.location.href='parent_messages.html?new=true'">
                        <i class="fas fa-plus"></i> New Message
                    </button>
                </div>
            </div>

            <!-- Schedule Sessions -->
            <div class="dashboard-card card-blue">
                <div class="card-header">
                    <div class="card-icon">
                        <i class="fas fa-calendar-plus"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Schedule Sessions</h3>
                        <p class="card-subtitle">Book tutoring sessions</p>
                    </div>
                </div>
                <div class="card-content">
                    <p>Schedule, reschedule, or cancel tutoring sessions with your child's tutors.</p>
                </div>
                <div class="card-actions">
                    <button class="btn btn-primary" onclick="window.location.href='parent_sessions.html'">
                        <i class="fas fa-calendar"></i> View Calendar
                    </button>
                    <button class="btn btn-secondary" onclick="window.location.href='parent_sessions.html?book=true'">
                        <i class="fas fa-plus"></i> Book Session
                    </button>
                </div>
            </div>

            <!-- Payment & Billing -->
            <div class="dashboard-card card-blue">
                <div class="card-header">
                    <div class="card-icon">
                        <i class="fas fa-credit-card"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Payment & Billing</h3>
                        <p class="card-subtitle">Manage subscriptions</p>
                    </div>
                </div>
                <div class="card-content">
                    <p>View invoices, update payment methods, and manage your tutoring subscriptions.</p>
                </div>
                <div class="card-actions">
                    <button class="btn btn-primary" onclick="window.location.href='parent_payments.html'">
                        <i class="fas fa-file-invoice"></i> View Invoices
                    </button>
                    <button class="btn btn-secondary" onclick="window.location.href='parent_payments.html?update=true'">
                        <i class="fas fa-edit"></i> Update Payment
                    </button>
                </div>
            </div>

            <!-- Resources -->
            <div class="dashboard-card card-blue">
                <div class="card-header">
                    <div class="card-icon">
                        <i class="fas fa-folder-open"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Learning Resources</h3>
                        <p class="card-subtitle">Access study materials</p>
                    </div>
                </div>
                <div class="card-content">
                    <p>Access study materials, assignments, and resources shared by your child's tutors.</p>
                </div>
                <div class="card-actions">
                    <button class="btn btn-primary" onclick="window.location.href='parent_resources.html'">
                        <i class="fas fa-folder-open"></i> View Resources
                    </button>
                    <button class="btn btn-secondary" onclick="downloadMaterials()">
                        <i class="fas fa-download"></i> Download
                    </button>
                </div>
            </div>

            <!-- Profile Settings -->
            <div class="dashboard-card card-blue">
                <div class="card-header">
                    <div class="card-icon">
                        <i class="fas fa-user-cog"></i>
                    </div>
                    <div>
                        <h3 class="card-title">Profile Settings</h3>
                        <p class="card-subtitle">Manage account & preferences</p>
                    </div>
                </div>
                <div class="card-content">
                    <p>Update your profile information, notification preferences, and account settings.</p>
                </div>
                <div class="card-actions">
                    <button class="btn btn-primary" onclick="window.location.href='parent_profile.html'">
                        <i class="fas fa-edit"></i> Edit Profile
                    </button>
                    <button class="btn btn-secondary" onclick="window.location.href='parent_settings.html'">
                        <i class="fas fa-cog"></i> Settings
                    </button>
                </div>
            </div>
        </div>
    </main>

    <!-- Notification -->
    <div class="notification" id="notification">
        <div id="notificationMessage">Operation completed successfully!</div>
    </div>

    <script>
        // Parent Dashboard JavaScript
        document.addEventListener('DOMContentLoaded', function () {
            // Initialize dashboard


            // Set active navigation based on current page
            setActiveNav();
        });

        function setActiveNav() {
            const currentPage = window.location.pathname.split('/').pop();
            document.querySelectorAll('.nav-links a').forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === currentPage) {
                    link.classList.add('active');
                }
            });
        }

        function downloadReport() {
            showNotification('Downloading progress report...');
            setTimeout(() => {
                showNotification('Report downloaded successfully');
                // In a real app, this would trigger a file download
            }, 1500);
        }

        function downloadMaterials() {
            showNotification('Downloading all materials...');
            setTimeout(() => {
                showNotification('Materials downloaded successfully');
            }, 1500);
        }

        function logout() {
            fetch("../auth/logout.php", { method: "POST" })
                .then(() => window.location.href = "../frontend/login.html");
        }


        // Notification function
        function showNotification(message, type = 'success') {
            const notification = document.getElementById('notification');
            const messageEl = document.getElementById('notificationMessage');

            messageEl.textContent = message;
            notification.className = 'notification ' + (type === 'error' ? 'notification-error' : 'notification-success');
            notification.classList.add('active');

            setTimeout(() => {
                notification.classList.remove('active');
            }, 3000);
        }
        
    </script>


</body>

</html>


