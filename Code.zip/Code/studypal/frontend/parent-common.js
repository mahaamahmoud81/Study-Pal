// parent-common.js - Shared JavaScript for all parent pages

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    initNavigation();
    initProfileDropdown();
    highlightActiveNav();
    initMobileMenu();
    updateStats();
});

// Navigation initialization
function initNavigation() {
    const currentPage = getCurrentPage();
    updateActiveNav(currentPage);
}

// Get current page from URL
function getCurrentPage() {
    const path = window.location.pathname;
    const page = path.split('/').pop().replace('.html', '');
    return page === 'parent_dashboard' ? 'dashboard' : page.replace('parent-', '').replace('_', '-');
}

// Update active navigation link
function updateActiveNav(page) {
    const navLinks = document.querySelectorAll('.nav-links a');
    const mobileLinks = document.querySelectorAll('.mobile-menu a');
    
    const updateLinks = (links) => {
        links.forEach(link => {
            link.classList.remove('active');
            const href = link.getAttribute('href');
            if (href && href.includes(page)) {
                link.classList.add('active');
            }
        });
    };
    
    updateLinks(navLinks);
    updateLinks(mobileLinks);
}

// Profile dropdown functionality
function initProfileDropdown() {
    const profileDropdown = document.querySelector('.profile-dropdown');
    if (!profileDropdown) return;

    profileDropdown.addEventListener('mouseenter', () => {
        const menu = profileDropdown.querySelector('.dropdown-menu');
        if (menu) menu.style.display = 'flex';
    });
    
    profileDropdown.addEventListener('mouseleave', () => {
        const menu = profileDropdown.querySelector('.dropdown-menu');
        if (menu) {
            setTimeout(() => {
                if (!menu.matches(':hover')) {
                    menu.style.display = 'none';
                }
            }, 300);
        }
    });

    // Keep menu open when hovering over it
    const dropdownMenu = profileDropdown.querySelector('.dropdown-menu');
    if (dropdownMenu) {
        dropdownMenu.addEventListener('mouseenter', () => {
            dropdownMenu.style.display = 'flex';
        });
        
        dropdownMenu.addEventListener('mouseleave', () => {
            dropdownMenu.style.display = 'none';
        });
    }
}

// Mobile menu functionality
function initMobileMenu() {
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const mobileMenu = document.getElementById('mobileMenu');
    
    if (mobileMenuBtn && mobileMenu) {
        mobileMenuBtn.addEventListener('click', toggleMobileMenu);
        
        // Close menu when clicking outside
        document.addEventListener('click', (event) => {
            if (!mobileMenu.contains(event.target) && !mobileMenuBtn.contains(event.target)) {
                mobileMenu.classList.remove('active');
            }
        });
    }
}

function toggleMobileMenu() {
    const mobileMenu = document.getElementById('mobileMenu');
    if (mobileMenu) {
        mobileMenu.classList.toggle('active');
    }
}

// Highlight active nav based on current page
function highlightActiveNav() {
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('.nav-links a');
    const mobileLinks = document.querySelectorAll('.mobile-menu a');
    
    const highlightLinks = (links) => {
        links.forEach(link => {
            const href = link.getAttribute('href');
            if (href && currentPath.includes(href)) {
                link.classList.add('active');
            }
        });
    };
    
    highlightLinks(navLinks);
    highlightLinks(mobileLinks);
}

// Update stats
function updateStats() {
    // Update stats with random numbers for demo
    const stats = {
        unreadMessages: Math.floor(Math.random() * 10) + 1,
        avgProgress: Math.floor(Math.random() * 20) + 80,
        upcomingSessions: Math.floor(Math.random() * 5) + 1,
        monthlyTotal: Math.floor(Math.random() * 300) + 200
    };
    
    // Update DOM elements if they exist
    const updateStat = (id, value, prefix = '', suffix = '') => {
        const element = document.getElementById(id);
        if (element) {
            if (typeof value === 'number' && id === 'monthlyTotal') {
                element.textContent = `£${value}`;
            } else {
                element.textContent = `${prefix}${value}${suffix}`;
            }
        }
    };
    
    updateStat('unreadMessages', stats.unreadMessages);
    updateStat('avgProgress', stats.avgProgress, '', '%');
    updateStat('upcomingSessions', stats.upcomingSessions);
    updateStat('monthlyTotal', stats.monthlyTotal);
}

// Message functions
function sendMessageToTutor(tutorId) {
    alert(`Sending message to tutor ${tutorId}...`);
    // In real app: window.location.href = `parent_messages.html?tutor=${tutorId}`;
}

function viewMessageDetails(messageId) {
    alert(`Viewing message ${messageId} details...`);
    // In real app: window.location.href = `parent_messages.html?message=${messageId}`;
}

function markMessageAsRead(messageId) {
    alert(`Marking message ${messageId} as read...`);
    // In real app: Update message status via API
}

function deleteMessage(messageId) {
    if (confirm('Are you sure you want to delete this message?')) {
        alert(`Message ${messageId} deleted successfully.`);
        // In real app: Remove message via API
    }
}

// Progress functions
function viewProgressReport(childId) {
    alert(`Viewing progress report for child ${childId}...`);
    // In real app: window.location.href = `parent_progress.html?child=${childId}`;
}

function downloadProgressReport(childId, period = 'monthly') {
    alert(`Downloading ${period} progress report for child ${childId}...`);
    // In real app: Download PDF via API
}

function compareProgress(child1Id, child2Id) {
    alert(`Comparing progress between child ${child1Id} and child ${child2Id}...`);
    // In real app: Open comparison chart
}

// Session functions
function bookNewSession() {
    alert('Opening session booking form...');
    // In real app: window.location.href = 'book_session.html';
}

function joinSession(sessionId) {
    alert(`Joining session ${sessionId}...`);
    // In real app: Redirect to video meeting
}

function rescheduleSession(sessionId) {
    alert(`Rescheduling session ${sessionId}...`);
    // In real app: Open rescheduling modal
}

function cancelSession(sessionId) {
    if (confirm('Are you sure you want to cancel this session?')) {
        alert(`Session ${sessionId} cancelled successfully.`);
        // In real app: Cancel session via API
    }
}

function viewSessionDetails(sessionId) {
    alert(`Viewing details for session ${sessionId}...`);
    // In real app: Open session details modal
}

// Payment functions
function makePayment() {
    alert('Opening payment form...');
    // In real app: Open payment modal
}

function viewInvoice(invoiceId) {
    alert(`Viewing invoice ${invoiceId}...`);
    // In real app: Open invoice details
}

function downloadInvoice(invoiceId) {
    alert(`Downloading invoice ${invoiceId}...`);
    // In real app: Download PDF invoice
}

function updatePaymentMethod() {
    alert('Updating payment method...');
    // In real app: Open payment method form
}

// Tutor functions
function messageTutor(tutorId) {
    alert(`Messaging tutor ${tutorId}...`);
    // In real app: window.location.href = `parent_messages.html?tutor=${tutorId}`;
}

function viewTutorProfile(tutorId) {
    alert(`Viewing tutor ${tutorId} profile...`);
    // In real app: Open tutor profile modal
}

function rateTutor(tutorId) {
    alert(`Rating tutor ${tutorId}...`);
    // In real app: Open rating modal
}

function requestTutorChange(tutorId) {
    if (confirm('Are you sure you want to request a tutor change?')) {
        alert(`Tutor change requested for ${tutorId}`);
        // In real app: Submit change request via API
    }
}

// Child management functions
function addNewChild() {
    alert('Adding new child...');
    // In real app: Open child registration form
}

function editChildProfile(childId) {
    alert(`Editing child ${childId} profile...`);
    // In real app: Open child profile editor
}

function updateChildPreferences(childId) {
    alert(`Updating preferences for child ${childId}...`);
    // In real app: Open preferences form
}

// Settings functions
function updateProfile() {
    alert('Updating profile...');
    // In real app: Open profile editor
}

function changePassword() {
    alert('Changing password...');
    // In real app: Open password change form
}

function updateNotificationSettings() {
    alert('Updating notification settings...');
    // In real app: Open notification settings
}

// Utility functions
function formatDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    
    return date.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric',
        year: diffDays < 365 ? undefined : 'numeric'
    });
}

function formatCurrency(amount, currency = 'GBP') {
    return new Intl.NumberFormat('en-GB', {
        style: 'currency',
        currency: currency
    }).format(amount);
}

function formatTimeRange(start, end) {
    const startTime = new Date(start).toLocaleTimeString('en-GB', {
        hour: '2-digit',
        minute: '2-digit'
    });
    const endTime = new Date(end).toLocaleTimeString('en-GB', {
        hour: '2-digit',
        minute: '2-digit'
    });
    return `${startTime} - ${endTime}`;
}

// Data loading functions
function loadSampleMessages() {
    return [
        {
            id: 1,
            sender: 'James Wilson',
            avatar: 'JW',
            role: 'Math Tutor',
            subject: 'Progress Update - Emily',
            preview: 'Emily has shown excellent progress in algebra this week...',
            content: 'Emily has shown excellent progress in algebra this week. She has mastered quadratic equations and is now working on advanced factoring techniques. Her problem-solving speed has improved by 40% compared to last month.',
            time: '2024-01-20T14:30:00',
            unread: true,
            attachments: ['Progress_Report.pdf', 'Worksheets.pdf']
        },
        {
            id: 2,
            sender: 'Emma Davis',
            avatar: 'ED',
            role: 'English Tutor',
            subject: 'Essay Feedback - Oliver',
            preview: 'Oliver\'s essay demonstrated strong analytical skills...',
            content: 'Oliver\'s essay on Macbeth demonstrated strong analytical skills and a good understanding of the play\'s themes. I\'ve provided detailed feedback on structure and argument development.',
            time: '2024-01-19T11:15:00',
            unread: true,
            attachments: ['Essay_Feedback.pdf']
        },
        {
            id: 3,
            sender: 'StudyPals Support',
            avatar: 'SS',
            role: 'Support Team',
            subject: 'Monthly Summary Available',
            preview: 'Your monthly progress summary is now ready...',
            content: 'Your monthly progress summary for both children is now available. You can download detailed reports and view analytics in your dashboard.',
            time: '2024-01-18T09:00:00',
            unread: false,
            attachments: ['Monthly_Report.pdf']
        }
    ];
}

function loadSampleChildren() {
    return [
        {
            id: 'emily',
            name: 'Emily Johnson',
            avatar: 'EJ',
            age: 14,
            grade: 'Year 9',
            subjects: [
                { name: 'Mathematics', progress: 92, tutor: 'James Wilson' },
                { name: 'English', progress: 84, tutor: 'Emma Davis' },
                { name: 'Science', progress: 85, tutor: 'Liam Johnson' }
            ],
            overallProgress: 87,
            upcomingSessions: 3
        },
        {
            id: 'oliver',
            name: 'Oliver Johnson',
            avatar: 'OJ',
            age: 12,
            grade: 'Year 7',
            subjects: [
                { name: 'Mathematics', progress: 80, tutor: 'James Wilson' },
                { name: 'English', progress: 85, tutor: 'Emma Davis' },
                { name: 'Science', progress: 81, tutor: 'Liam Johnson' }
            ],
            overallProgress: 82,
            upcomingSessions: 2
        }
    ];
}

function loadSampleSessions() {
    return [
        {
            id: 1,
            childId: 'emily',
            tutor: 'James Wilson',
            subject: 'Mathematics',
            date: '2024-01-22',
            startTime: '15:00',
            endTime: '16:30',
            duration: 90,
            status: 'upcoming',
            meetingLink: 'https://meet.studypals.com/abc123'
        },
        {
            id: 2,
            childId: 'oliver',
            tutor: 'Emma Davis',
            subject: 'English',
            date: '2024-01-22',
            startTime: '17:00',
            endTime: '18:00',
            duration: 60,
            status: 'upcoming',
            meetingLink: 'https://meet.studypals.com/def456'
        },
        {
            id: 3,
            childId: 'oliver',
            tutor: 'Liam Johnson',
            subject: 'Science',
            date: '2024-01-23',
            startTime: '16:00',
            endTime: '17:30',
            duration: 90,
            status: 'upcoming',
            meetingLink: 'https://meet.studypals.com/ghi789'
        }
    ];
}

function loadSamplePayments() {
    return [
        {
            id: 1,
            date: '2024-01-15',
            description: 'January Tutoring Sessions',
            amount: 320,
            status: 'paid',
            invoiceUrl: '/invoices/january.pdf'
        },
        {
            id: 2,
            date: '2024-01-10',
            description: 'Additional Session - Emily',
            amount: 60,
            status: 'paid',
            invoiceUrl: '/invoices/additional.pdf'
        },
        {
            id: 3,
            date: '2024-01-05',
            description: 'Resource Materials',
            amount: 45,
            status: 'pending',
            invoiceUrl: '/invoices/resources.pdf'
        }
    ];
}

// Logout function
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        alert('Logging out...');
        // In real app: Clear session and redirect to login
        // window.location.href = 'login.html';
    }
}

// Export functions for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        initNavigation,
        initProfileDropdown,
        highlightActiveNav,
        updateStats,
        formatDate,
        formatCurrency,
        formatTimeRange,
        loadSampleMessages,
        loadSampleChildren,
        loadSampleSessions,
        loadSamplePayments,
        logout
    };
}