<?php
session_start();
require_once "../includes/db_connect.php";

if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "tutor") {
    die("Access denied");
}

$tutorId = $_SESSION["user_id"];

$stmt = $pdo->prepare("
    SELECT id, title 
    FROM courses 
    WHERE tutor_id = ?
");
$stmt->execute([$tutorId]);
$courses = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create Quiz</title>
</head>
<body>
<h2>Create Quiz</h2>

<form method="post" action="../api/save_quiz.php">
    <label>Course</label>
    <select name="course_id" required>
        <?php foreach ($courses as $c): ?>
            <option value="<?= $c["id"] ?>"><?= htmlspecialchars($c["title"]) ?></option>
        <?php endforeach; ?>
    </select><br><br>

    <label>Quiz Title</label>
    <input type="text" name="title" required><br><br>

    <label>Total Marks</label>
    <input type="number" name="total_marks" required><br><br>

    <button type="submit">Create Quiz</button>
</form>
</body>
</html>
