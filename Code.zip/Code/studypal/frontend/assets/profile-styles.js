// common-script.js - Shared JavaScript for all tutor pages

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    initNavigation();
    initProfileDropdown();
    highlightActiveNav();
    initStats();
});

// Navigation initialization
function initNavigation() {
    const currentPage = getCurrentPage();
    updateActiveNav(currentPage);
}

// Get current page from URL
function getCurrentPage() {
    const path = window.location.pathname;
    const page = path.split('/').pop().replace('.html', '');
    return page === 'tutor-dashboard' ? 'dashboard' : page.replace('tutor-', '').replace('-', '');
}

// Update active navigation link
function updateActiveNav(page) {
    const navLinks = document.querySelectorAll('.nav-links a');
    navLinks.forEach(link => {
        link.classList.remove('active');
        const href = link.getAttribute('href');
        if (href && href.includes(page)) {
            link.classList.add('active');
        }
    });
}

// Profile dropdown functionality
function initProfileDropdown() {
    const profileDropdown = document.querySelector('.profile-dropdown');
    if (!profileDropdown) return;

    profileDropdown.addEventListener('mouseenter', () => {
        const menu = profileDropdown.querySelector('.dropdown-menu');
        if (menu) menu.style.display = 'flex';
    });
    
    profileDropdown.addEventListener('mouseleave', () => {
        const menu = profileDropdown.querySelector('.dropdown-menu');
        if (menu) {
            setTimeout(() => {
                menu.style.display = 'none';
            }, 300);
        }
    });
}

// Highlight active nav based on current page
function highlightActiveNav() {
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('.nav-links a');
    
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (currentPath.includes(href)) {
            link.classList.add('active');
        }
    });
}

// Initialize stats
function initStats() {
    // Update stats with random numbers for demo
    const stats = {
        totalStudents: Math.floor(Math.random() * 50) + 20,
        totalCourses: Math.floor(Math.random() * 10) + 4,
        pendingAssignments: Math.floor(Math.random() * 20) + 5
    };
    
    // Update DOM elements if they exist
    const updateStat = (id, value) => {
        const element = document.getElementById(id);
        if (element) element.textContent = value;
    };
    
    updateStat('totalStudents', stats.totalStudents);
    updateStat('totalCourses', stats.totalCourses);
    updateStat('pendingAssignments', stats.pendingAssignments);
}

// Alert functions for demo purposes
function createNewCourse() {
    alert('Create New Course: This would open a course creation form.');
}

function uploadFile() {
    alert('Upload File: This would open a file upload dialog.');
}

function viewQuizDetails() {
    alert('View Quiz Details: This would show detailed quiz analytics.');
}

function addNewSession() {
    alert('Add Session: This would open a session scheduling form.');
}

function viewPendingAssignments() {
    window.location.href = 'grade-assignments.html';
}

function generateReport() {
    alert('Generate Report: This would generate and download a student analytics report.');
}

// Course management functions
function editCourse(courseId) {
    alert(`Edit Course ${courseId}: This would open the course editor.`);
}

function deleteCourse(courseId) {
    if (confirm('Are you sure you want to delete this course?')) {
        alert(`Course ${courseId} deleted successfully.`);
        // In a real app, this would remove the course from the DOM
    }
}

// Resource management functions
function downloadResource(resourceName) {
    alert(`Downloading ${resourceName}...`);
}

function shareResource(resourceName) {
    alert(`Sharing ${resourceName} with students...`);
}

// Assignment grading functions
function gradeAssignment(assignmentId) {
    alert(`Grading Assignment ${assignmentId}: This would open the grading interface.`);
}

function viewAssignmentDetails(assignmentId) {
    alert(`Viewing details for Assignment ${assignmentId}...`);
}

// Session management functions
function cancelSession(sessionId) {
    if (confirm('Are you sure you want to cancel this session?')) {
        alert(`Session ${sessionId} cancelled.`);
    }
}

function rescheduleSession(sessionId) {
    alert(`Reschedule Session ${sessionId}: This would open the rescheduling form.`);
}

// Analytics functions
function exportData() {
    alert('Exporting analytics data...');
}

function filterByDate() {
    alert('Filter by Date: This would show date filtering options.');
}

// Logout function
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        alert('Logging out...');
        // In a real app, this would redirect to login page
        // window.location.href = 'login.html';
    }
}

// Utility function to format date
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Load sample data for demo
function loadSampleCourses() {
    return [
        {
            id: 1,
            title: 'Calculus 101',
            code: 'MATH101',
            students: 24,
            modules: 8,
            progress: 75,
            status: 'active'
        },
        {
            id: 2,
            title: 'Physics 201',
            code: 'PHYS201',
            students: 18,
            modules: 6,
            progress: 90,
            status: 'active'
        },
        {
            id: 3,
            title: 'Computer Science 301',
            code: 'CS301',
            students: 32,
            modules: 10,
            progress: 60,
            status: 'active'
        },
        {
            id: 4,
            title: 'Organic Chemistry',
            code: 'CHEM301',
            students: 15,
            modules: 7,
            progress: 45,
            status: 'draft'
        }
    ];
}

function loadSampleResources() {
    return [
        {
            id: 1,
            name: 'Calculus Lecture Notes',
            course: 'Calculus 101',
            type: 'pdf',
            size: '2.4 MB',
            date: '2024-01-15',
            downloads: 142
        },
        {
            id: 2,
            name: 'Physics Lab Manual',
            course: 'Physics 201',
            type: 'pdf',
            size: '3.1 MB',
            date: '2024-01-10',
            downloads: 98
        },
        {
            id: 3,
            name: 'Programming Exercises',
            course: 'Computer Science 301',
            type: 'zip',
            size: '5.2 MB',
            date: '2024-01-05',
            downloads: 203
        }
    ];
}

function loadSampleAssignments() {
    return [
        {
            id: 1,
            student: 'Alice Johnson',
            course: 'Calculus 101',
            assignment: 'Derivatives Homework',
            submitted: '2024-01-20',
            status: 'pending',
            grade: null
        },
        {
            id: 2,
            student: 'David Lee',
            course: 'Physics 201',
            assignment: 'Lab Report #3',
            submitted: '2024-01-19',
            status: 'pending',
            grade: null
        },
        {
            id: 3,
            student: 'Maria Smith',
            course: 'Computer Science 301',
            assignment: 'Programming Project',
            submitted: '2024-01-18',
            status: 'graded',
            grade: 'A-'
        }
    ];
}