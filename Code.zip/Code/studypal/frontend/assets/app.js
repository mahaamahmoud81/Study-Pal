/* assets/app.js
   Put this file in assets/app.js
   Contains helper functions and example fetch calls to render JSON
*/

/* --- Config --- */
const API_BASE = './api'; // change if your api route is different

/* --- Helpers --- */
function qs(sel) { return document.querySelector(sel) }
function qsa(sel) { return [...document.querySelectorAll(sel)] }
function showToast(msg) { alert(msg) } // swap for nicer toast if desired

/* --- Example: tutor search fetch --- */
async function tutorSearch({ subject = '', level = '' }) {
  // Example GET: api/tutor_search.php?subject=Maths&level=GCSE
  const url = `${API_BASE}/tutor_search.php?subject=${encodeURIComponent(subject)}&level=${encodeURIComponent(level)}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Network error');
  const json = await res.json();
  // expected: array of tutor objects
  return json;
}
event.preventDefault();
event.stopPropagation();

/* --- Render tutors (example for tutor_finder.html) --- */
function renderTutorResults(containerEl, tutors = []) {
  containerEl.innerHTML = '';
  if (!tutors.length) {
    containerEl.innerHTML = `<div class="card"><p class="small">No tutors found.</p></div>`;
    return;
  }
  const grid = document.createElement('div');
  grid.className = 'grid';
  tutors.forEach(t => {
    const div = document.createElement('div');
    div.className = 'card tutor-card';
    div.innerHTML = `
      <img src="${t.profile_image || 'assets/placeholder.png'}" alt="Tutor">
      <div class="info">
        <div style="display:flex;justify-content:space-between;align-items:start">
          <div>
            <div style="font-weight:600">${t.name || 'Unknown'}</div>
            <div class="small">${t.qualification || ''} · ${t.subjects || ''}</div>
          </div>
          <div class="price">£${t.hourly_rate || '—'}</div>
        </div>
        <p class="small">${t.bio ? (t.bio.slice(0, 140)) : ''}</p>
        <div style="margin-top:8px"><a class="btn" href="tutor_profile.html?id=${t.id}">View profile</a></div>
      </div>
    `;
    grid.appendChild(div);
  });
  containerEl.appendChild(grid);
}

/* --- Example: dashboard student GET --- */
async function loadStudentDashboard(containerEl) {
  const url = `${API_BASE}/dashboard_student.php`;
  const res = await fetch(url, { credentials: 'same-origin' });
  if (!res.ok) { containerEl.innerHTML = '<div class="card small">Error loading dashboard</div>'; return }
  const data = await res.json();
  // TODO: adapt to your backend's JSON shape
  containerEl.innerHTML = `
    <div class="card"><h3>Welcome, ${data.user?.name || 'Student'}</h3>
      <p class="small">You are enrolled in <strong>${data.courses?.length || 0}</strong> courses</p>
    </div>
  `;
  // render courses and progress below (example)
  if (Array.isArray(data.courses) && data.courses.length) {
    const list = document.createElement('div');
    list.className = 'grid';
    data.courses.forEach(c => {
      const el = document.createElement('div');
      el.className = 'card';
      el.innerHTML = `<div style="display:flex;justify-content:space-between"><div><strong>${c.title}</strong><div class="small">${c.tutor_name || ''}</div></div><div class="small">${c.progress || 0}%</div></div>`;
      list.appendChild(el);
    });
    containerEl.appendChild(list);
  }
}

/* --- Form submit example for register/login (used in login.html and register.html) --- */
async function postForm(url, formEl) {
  const formData = new FormData(formEl);
  // If multipart needed (e.g., tutor certificate/photo), form has file inputs
  const res = await fetch(url, { method: 'POST', body: formData, credentials: 'same-origin' });
  if (!res.ok) throw new Error('Server error');
  const json = await res.json();
  return json;
}

/* Exports (attach to window to call from HTML) */
window.app = {
  tutorSearch, renderTutorResults, loadStudentDashboard, postForm, API_BASE
};