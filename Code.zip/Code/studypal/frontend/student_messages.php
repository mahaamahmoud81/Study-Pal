<?php
session_start();

if (!isset($_SESSION["isLoggedIn"]) || ($_SESSION["role"] ?? "") !== "student") {
    header("Location: login.html");
    exit;
}

$fullName  = (string)($_SESSION["full_name"] ?? "Student");
$initials = "ST";
$parts = preg_split('/\s+/', trim($fullName));
if ($parts && count($parts) >= 2) $initials = strtoupper(mb_substr($parts[0], 0, 1) . mb_substr($parts[1], 0, 1));
elseif ($parts && count($parts) === 1 && $parts[0] !== "") $initials = strtoupper(mb_substr($parts[0], 0, 2));
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>StudyPals — Messages</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/styles.css">
    <link rel="stylesheet" href="assets/profile-styles.css">
    <style>
        :root {
            --accent: #3b82f6;
            --accent-dark: #2563eb;
            --accent-light: #60a5fa;
            --accent-hover: rgba(59, 130, 246, 0.1);
            --accent-active: rgba(59, 130, 246, 0.2);
            --bg: #0f172a;
            --card: #1e293b;
            --card-hover: #334155;
            --text: #f1f5f9;
            --text-muted: #94a3b8;
            --border: #334155;
            --success: #34d399;
            --danger: #f87171;
            --warning: #fbbf24;
            --purple: #8b5cf6;
            --pink: #ec4899;
            --orange: #f59e0b;
            --cyan: #06b6d4;
            --radius: 16px;
            --radius-sm: 8px;
            --shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
        }

        body {
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
            overflow-x: hidden;
        }

        .nav {
            background: var(--card);
            border-bottom: 1px solid var(--border);
            padding: 0 24px;
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 0;
        }

        .brand {
            font-size: 28px;
            font-weight: 800;
            background: linear-gradient(135deg, var(--accent), var(--accent-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
        }

        .nav-links {
            display: flex;
            gap: 16px;
            align-items: center;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--text-muted);
            font-weight: 500;
            padding: 8px 12px;
            border-radius: var(--radius-sm);
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 14px;
        }

        .nav-links a:hover {
            color: var(--text);
            background: var(--accent-hover);
        }

        .nav-links a.active {
            color: var(--accent);
            background: var(--accent-active);
        }

        .profile-dropdown {
            position: relative;
        }

        .profile-btn {
            background: none;
            border: none;
            color: var(--text);
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: var(--radius-sm);
            transition: var(--transition);
        }

        .profile-btn:hover {
            background: var(--accent-hover);
        }

        .profile-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--accent), var(--accent-dark));
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }

        .dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            min-width: 200px;
            box-shadow: var(--shadow);
            display: none;
            z-index: 1000;
        }

        .profile-dropdown:hover .dropdown-menu,
        .profile-dropdown:focus-within .dropdown-menu {
            display: block;
        }

        .dropdown-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: var(--text);
            text-decoration: none;
            transition: var(--transition);
            border-bottom: 1px solid var(--border);
        }

        .dropdown-item:last-child {
            border-bottom: none;
        }

        .dropdown-item:hover {
            background: var(--accent-hover);
            color: var(--accent);
        }

        .dropdown-item.logout {
            color: var(--danger);
        }

        .dropdown-item.logout:hover {
            background: rgba(248, 113, 113, 0.1);
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 40px 24px;
        }

        .messages-header {
            background: var(--card);
            border-radius: var(--radius);
            padding: 40px;
            border: 1px solid var(--border);
            margin-bottom: 40px;
            position: relative;
            overflow: hidden;
        }

        .messages-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--accent), var(--accent-dark));
        }

        .header-content h1 {
            font-size: 2.5rem;
            margin-bottom: 8px;
            background: linear-gradient(135deg, var(--text), var(--accent-light));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .header-content p {
            color: var(--text-muted);
            font-size: 1.1rem;
            margin-bottom: 24px;
        }

        .message-stats {
            display: flex;
            gap: 32px;
            margin-top: 32px;
            flex-wrap: wrap;
        }

        .stat-badge {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
            padding: 16px 24px;
            background: rgba(15, 23, 42, 0.5);
            border-radius: var(--radius);
            border: 1px solid var(--border);
            min-width: 120px;
            cursor: pointer;
            transition: var(--transition);
            text-decoration: none;
            color: inherit;
        }

        .stat-badge:hover {
            border-color: var(--accent);
            transform: translateY(-2px);
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--accent);
        }

        .stat-label {
            font-size: 0.9rem;
            color: var(--text-muted);
            text-align: center;
        }

        .messages-wrapper {
            display: flex;
            gap: 30px;
            background: var(--card);
            border-radius: var(--radius);
            overflow: hidden;
            border: 1px solid var(--border);
            min-height: 600px;
        }

        .conversations-list {
            width: 320px;
            border-right: 1px solid var(--border);
            background: rgba(30, 41, 59, 0.5);
            display: flex;
            flex-direction: column;
        }

        .conversations-header {
            padding: 25px;
            border-bottom: 1px solid var(--border);
            background: var(--card);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .conversations-header h3 {
            margin: 0;
            color: var(--text);
        }

        .new-conversation-btn {
            background: transparent;
            border: none;
            color: var(--accent);
            cursor: pointer;
            padding: 8px;
            border-radius: var(--radius-sm);
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .new-conversation-btn:hover {
            background: var(--accent-hover);
        }

        .conversations-scroll {
            flex: 1;
            overflow-y: auto;
        }

        .conversation-item {
            padding: 20px;
            border-bottom: 1px solid var(--border);
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .conversation-item:hover {
            background: var(--accent-hover);
        }

        .conversation-item.active {
            background: var(--accent-active);
            border-right: 3px solid var(--accent);
        }

        .conversation-avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            overflow: hidden;
            border: 2px solid var(--accent);
            background: linear-gradient(135deg, var(--accent), var(--accent-dark));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 18px;
        }

        .conversation-info {
            flex: 1;
        }

        .conversation-info h5 {
            margin: 0 0 5px 0;
            color: var(--text);
            font-size: 15px;
        }

        .conversation-info p {
            margin: 0;
            color: var(--text-muted);
            font-size: 13px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 180px;
        }

        .conversation-meta {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            gap: 5px;
        }

        .conversation-time {
            color: var(--text-muted);
            font-size: 12px;
        }

        .unread-badge {
            background: var(--accent);
            color: white;
            padding: 4px 8px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            min-width: 20px;
            text-align: center;
        }

        .message-area {
            flex: 1;
            display: flex;
            flex-direction: column;
            display: none;
        }

        .message-header {
            padding: 25px;
            border-bottom: 1px solid var(--border);
            background: var(--card);
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .message-header-avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            overflow: hidden;
            border: 2px solid var(--accent);
            background: linear-gradient(135deg, var(--accent), var(--accent-dark));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 18px;
        }

        .message-header-info h4 {
            margin: 0 0 5px 0;
            color: var(--text);
        }

        .message-header-info p {
            margin: 0;
            color: var(--text-muted);
            font-size: 14px;
        }

        .messages-list {
            flex: 1;
            padding: 25px;
            overflow-y: auto;
            background: rgba(30, 41, 59, 0.5);
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .message {
            max-width: 70%;
            animation: messageIn 0.4s ease-out;
        }

        @keyframes messageIn {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .message.received { margin-right: auto; }
        .message.sent { margin-left: auto; }

        .message-bubble {
            padding: 18px;
            border-radius: var(--radius);
            background: var(--card);
            border: 1px solid var(--border);
            position: relative;
            transition: var(--transition);
        }

        .message.sent .message-bubble {
            background: linear-gradient(135deg, var(--accent), var(--accent-dark));
            border: none;
            color: white;
        }

        .message.sent .message-bubble::after {
            content: '';
            position: absolute;
            right: -8px;
            top: 50%;
            transform: translateY(-50%);
            border: 8px solid transparent;
            border-left-color: var(--accent);
        }

        .message.received .message-bubble::after {
            content: '';
            position: absolute;
            left: -8px;
            top: 50%;
            transform: translateY(-50%);
            border: 8px solid transparent;
            border-right-color: var(--card);
        }

        .message-time {
            color: var(--text-muted);
            margin-top: 8px;
            font-size: 12px;
            text-align: right;
        }

        .message-input {
            padding: 25px;
            border-top: 1px solid var(--border);
            background: var(--card);
        }

        .message-input form {
            display: flex;
            gap: 15px;
        }

        .message-input textarea {
            flex: 1;
            padding: 18px;
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            resize: none;
            font-family: inherit;
            font-size: 14px;
            transition: var(--transition);
            background: rgba(30, 41, 59, 0.8);
            color: var(--text);
        }

        .message-input textarea:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        .btn {
            padding: 12px 24px;
            border-radius: var(--radius-sm);
            border: none;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--accent), var(--accent-dark));
            color: white;
            border: 1px solid var(--accent);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(59, 130, 246, 0.4);
        }

        .btn-outline {
            background: transparent;
            border: 2px solid var(--accent);
            color: var(--accent);
        }

        .btn-outline:hover {
            background: var(--accent-hover);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(59, 130, 246, 0.2);
        }

        .welcome-message {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 60px;
            text-align: center;
            color: var(--text-muted);
        }

        .welcome-message i {
            font-size: 60px;
            margin-bottom: 20px;
            opacity: 0.5;
        }

        .welcome-message h3 {
            color: var(--text);
            margin-bottom: 10px;
        }

        @media (max-width: 1024px) {
            .messages-wrapper { flex-direction: column; }
            .conversations-list {
                width: 100%;
                height: 350px;
                border-right: none;
                border-bottom: 1px solid var(--border);
            }
            .conversations-scroll { height: 300px; }
        }

        @media (max-width: 768px) {
            .nav-links a:not(.active) { display: none; }
            .message-stats { flex-wrap: wrap; justify-content: center; gap: 20px; }
            .stat-badge { min-width: 100px; padding: 12px 16px; }
            .message { max-width: 85%; }
            .message-input form { flex-direction: column; }
            .btn { width: 100%; justify-content: center; }
        }
    </style>
</head>

<body>
    <header class="nav">
        <div class="nav-container">
            <div class="brand" onclick="window.location.href='student_home_profile.php'">
                <i class="fas fa-graduation-cap"></i>
                StudyPals
            </div>
            <nav class="nav-links">
                <a href="student_home_profile.php">
                    <i class="fas fa-home"></i> Home
                </a>
                <a href="mycourses.html">
                    <i class="fas fa-book-open"></i> My Courses
                </a>
                <a href="student_messages.php" class="active">
                    <i class="fas fa-messages"></i> Messages
                </a>
                <a href="student_schedule.html">
                    <i class="fas fa-calendar-alt"></i> Schedule
                </a>
                <a href="assignments.html">
                    <i class="fas fa-tasks"></i> Assignments
                </a>
                <a href="student_analytics.html">
                    <i class="fas fa-chart-line"></i> Analytics
                </a>
                <a href="student_resources.html">
                    <i class="fas fa-folder-open"></i> Resources
                </a>
                <div class="profile-dropdown">
                    <button class="profile-btn">
                        <div class="profile-avatar"><?= htmlspecialchars($initials) ?></div>
                        <i class="fas fa-chevron-down"></i>
                    </button>
                    <div class="dropdown-menu">
                        <a href="student_profile.html" class="dropdown-item">
                            <i class="fas fa-user"></i> My Profile
                        </a>
                        <a href="student_settings.html" class="dropdown-item">
                            <i class="fas fa-cog"></i> Settings
                        </a>
                        <a href="#" class="dropdown-item logout" onclick="logout()">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>
            </nav>
        </div>
    </header>

    <main class="container">
        <div class="messages-header">
            <div class="header-content">
                <h1>Messages</h1>
                <p>Chat with your tutors and stay connected</p>
                <div class="message-stats">
                    <a href="#" class="stat-badge" onclick="filterByType('unread')">
                        <span class="stat-value" id="unreadCount">0</span>
                        <span class="stat-label">Unread Messages</span>
                    </a>
                    <a href="#" class="stat-badge" onclick="filterByType('active')">
                        <span class="stat-value" id="activeConvos">0</span>
                        <span class="stat-label">Active Conversations</span>
                    </a>
                    <a href="#" class="stat-badge" onclick="filterByType('tutor')">
                        <span class="stat-value" id="tutorCount">0</span>
                        <span class="stat-label">Tutor Messages</span>
                    </a>
                    <a href="#" class="stat-badge" onclick="newMessage()">
                        <span class="stat-value">+</span>
                        <span class="stat-label">New Message</span>
                    </a>
                </div>
            </div>
        </div>

        <div class="messages-wrapper">
            <div class="conversations-list">
                <div class="conversations-header">
                    <h3>Conversations</h3>

                    <form method="post" action="../api/start_message.php">
                        <input type="hidden" name="receiver_id" value="1"> <!-- tutor user_id -->
                        <button type="submit" class="new-conversation-btn">
                            <i class="fas fa-plus"></i> New
                        </button>
                    </form>

                    <div class="conversations-scroll" id="conversationsScroll"></div>
                </div>
            </div>

            <div class="welcome-message" id="welcomeMessage">
                <i class="fas fa-comments"></i>
                <h3>Select a conversation</h3>
                <p>Choose a user from the list to start messaging</p>
            </div>

            <div class="message-area" id="messageArea">
                <div class="message-header" id="messageHeader">
                    <div class="message-header-avatar" id="currentChatAvatar"></div>
                    <div class="message-header-info">
                        <h4 id="currentChatName"></h4>
                        <p id="currentChatCourse"></p>
                    </div>
                </div>

                <div class="messages-list" id="messagesList"></div>

                <div class="message-input">
                    <form id="messageForm">
                        <textarea id="messageInput" placeholder="Type your message here..." rows="3"></textarea>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-paper-plane"></i> Send
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <script>
        let conversations = [];
        let currentConversationUserId = null;
        let currentFilter = null;

        document.addEventListener('DOMContentLoaded', async function () {
            setActiveNav();
            document.getElementById('messageForm').addEventListener('submit', sendMessage);
            await refreshConversations();
        });

        function setActiveNav() {
            const currentPage = window.location.pathname.split('/').pop();
            document.querySelectorAll('.nav-links a').forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === currentPage) {
                    link.classList.add('active');
                }
            });
        }

        async function refreshConversations() {
            const res = await fetch('../api/messages_conversations.php', { credentials: 'same-origin' });
            const data = await res.json();
            conversations = Array.isArray(data.conversations) ? data.conversations : [];
            updateStats();
            loadConversations();
        }

        function updateStats() {
            const unreadCount = conversations.reduce((sum, c) => sum + (parseInt(c.unread || 0, 10)), 0);
            const activeConvos = conversations.length;
            const tutorCount = conversations.filter(c => (c.other_role || '') === 'tutor').length;

            document.getElementById('unreadCount').textContent = unreadCount;
            document.getElementById('activeConvos').textContent = activeConvos;
            document.getElementById('tutorCount').textContent = tutorCount;
        }

        function filterByType(filterType) {
            currentFilter = filterType;
            loadConversations();
        }

        function loadConversations() {
            const conversationsScroll = document.getElementById('conversationsScroll');
            conversationsScroll.innerHTML = '';

            let filtered = conversations;

            if (currentFilter === 'unread') filtered = conversations.filter(c => (c.unread || 0) > 0);
            if (currentFilter === 'tutor') filtered = conversations.filter(c => (c.other_role || '') === 'tutor');
            if (currentFilter === 'active') filtered = conversations;

            if (filtered.length === 0) {
                conversationsScroll.innerHTML = `
                    <div style="padding: 40px; text-align: center; color: var(--text-muted);">
                        <i class="fas fa-comments" style="font-size: 40px; margin-bottom: 15px; opacity: 0.5;"></i>
                        <p>No conversations yet</p>
                    </div>
                `;
                return;
            }

            filtered.forEach(c => {
                const initials = (c.other_initials || '??');
                const convItem = document.createElement('div');
                convItem.className = `conversation-item ${c.other_user_id == currentConversationUserId ? 'active' : ''}`;
                convItem.dataset.userId = c.other_user_id;
                convItem.innerHTML = `
                    <div class="conversation-avatar">${initials}</div>
                    <div class="conversation-info">
                        <h5>${escapeHtml(c.other_name || 'User')}</h5>
                        <p>${escapeHtml(c.last_message || '')}</p>
                    </div>
                    <div class="conversation-meta">
                        <span class="conversation-time">${escapeHtml(c.last_time_label || '')}</span>
                        ${c.unread > 0 ? `<span class="unread-badge">${c.unread}</span>` : ``}
                    </div>
                `;
                convItem.addEventListener('click', () => openConversation(c.other_user_id, c.other_name, initials));
                conversationsScroll.appendChild(convItem);
            });
        }

        async function openConversation(otherUserId, otherName, initials) {
            currentConversationUserId = otherUserId;

            document.getElementById('welcomeMessage').style.display = 'none';
            document.getElementById('messageArea').style.display = 'flex';

            document.querySelectorAll('.conversation-item').forEach(item => item.classList.remove('active'));
            const el = document.querySelector(`.conversation-item[data-user-id="${otherUserId}"]`);
            if (el) el.classList.add('active');

            document.getElementById('currentChatName').textContent = otherName || 'User';
            document.getElementById('currentChatCourse').textContent = ''; // keep UI, no fake course
            document.getElementById('currentChatAvatar').textContent = initials || '??';

            await loadMessages(otherUserId);
        }

        async function loadMessages(otherUserId) {
            const messagesList = document.getElementById('messagesList');
            messagesList.innerHTML = '';

            const res = await fetch(`../api/messages_thread.php?user_id=${encodeURIComponent(otherUserId)}`, { credentials: 'same-origin' });
            const data = await res.json();

            const msgs = Array.isArray(data.messages) ? data.messages : [];
            if (msgs.length === 0) {
                messagesList.innerHTML = `
                    <div style="text-align: center; padding: 40px; color: var(--text-muted);">
                        <p>No messages yet. Start the conversation!</p>
                    </div>
                `;
                return;
            }

            msgs.forEach(m => {
                const div = document.createElement('div');
                div.className = `message ${m.is_sent ? 'sent' : 'received'}`;
                div.innerHTML = `
                    <div class="message-bubble">${escapeHtml(m.body || '')}</div>
                    <div class="message-time">${escapeHtml(m.time_label || '')}</div>
                `;
                messagesList.appendChild(div);
            });

            messagesList.scrollTop = messagesList.scrollHeight;
            await refreshConversations();
        }

        async function sendMessage(e) {
            e.preventDefault();

            const input = document.getElementById('messageInput');
            const body = input.value.trim();
            if (!body || !currentConversationUserId) return;

            const form = new FormData();
            form.append('receiver_id', currentConversationUserId);
            form.append('body', body);

            const res = await fetch('../api/message_send.php', {
                method: 'POST',
                body: form,
                credentials: 'same-origin'
            });

            const data = await res.json();
            if (!res.ok) {
                alert(data.error || 'Message failed');
                return;
            }

            input.value = '';
            await loadMessages(currentConversationUserId);
        }

        function newMessage() {
            alert('To start a new chat, you need at least one existing user to message. Once someone messages you or you message them, it will appear here.');
        }

        function logout() {
            if (confirm('Are you sure you want to logout?')) {
                window.location.href = '../auth/logout.php';
            }
        }

        function escapeHtml(str) {
            return String(str).replace(/[&<>"']/g, (m) => ({
                '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
            }[m]));
        }
    </script>
</body>

</html>
