<?php
session_start();
require_once "../includes/db_connect.php";

if ($_SESSION["role"] !== "student") {
    die("Access denied");
}

$studentId = $_SESSION["user_id"];

$stmt = $pdo->prepare("
    SELECT q.id, q.title, q.total_marks
    FROM quizzes q
    JOIN enrollments e ON e.course_id = q.course_id
    WHERE e.student_id = ?
");
$stmt->execute([$studentId]);
$quizzes = $stmt->fetchAll();
?>

<h2>Available Quizzes</h2>

<?php foreach ($quizzes as $q): ?>
<form method="post" action="../api/submit_quiz.php">
    <strong><?= htmlspecialchars($q["title"]) ?></strong><br>
    <input type="hidden" name="quiz_id" value="<?= $q["id"] ?>">
    <label>Score (test input)</label>
    <input type="number" name="score" required>
    <button type="submit">Submit</button>
</form>
<hr>
<?php endforeach; ?>
