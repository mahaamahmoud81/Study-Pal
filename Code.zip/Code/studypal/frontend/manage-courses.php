<?php
session_start();
if (!isset($_SESSION['isLoggedIn']) || ($_SESSION['role'] ?? '') !== 'tutor') {
  header("Location: /studypal/frontend/login.html"); exit;
}
include __DIR__ . "/manage-courses.html";
?>
<script>window.logout = () => window.location.href="/studypal/auth/logout.php";</script>
