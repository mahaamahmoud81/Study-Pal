<?php
session_start();
require_once "../includes/db_connect.php";
require_once "../includes/functions.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("Invalid request method.");
}

$full_name = trim($_POST["full_name"] ?? "");
$dob       = $_POST["dob"] ?? "";
$email     = strtolower(trim($_POST["email"] ?? ""));
$password  = $_POST["password"] ?? "";

if (!$full_name || !$dob || !$email || !$password) {
    die("Please fill out all fields.");
}

if (!validate_email($email)) {
    die("Invalid email format.");
}

// Check duplicate email
$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$email]);

if ($stmt->fetch()) {
    die("Email already registered.");
}

$password_hash = password_hash($password, PASSWORD_DEFAULT);

// Insert student (auto-approved)
$stmt = $pdo->prepare("
    INSERT INTO users (full_name, dob, email, password, role, approved)
    VALUES (?, ?, ?, ?, 'student', 1)
");

$stmt->execute([$full_name, $dob, $email, $password_hash]);

// Redirect to login page
header("Location: ../frontend/login.html");
exit;
