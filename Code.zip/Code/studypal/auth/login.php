<?php
// /studypal/auth/login.php
session_start();

require_once __DIR__ . "/../includes/db_connect.php";
require_once __DIR__ . "/../includes/functions.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    exit("POST required.");
}

$email = strtolower(trim($_POST["email"] ?? ""));
$password = (string)($_POST["password"] ?? "");
$returnTo = trim((string)($_POST["return_to"] ?? ""));

if ($email === "" || $password === "") {
    http_response_code(400);
    exit("Please enter email and password.");
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user || !password_verify($password, $user["password"])) {
    http_response_code(401);
    exit("Incorrect email or password.");
}

if (($user["role"] ?? "") === "tutor" && (int)($user["approved"] ?? 0) === 0) {
    http_response_code(403);
    exit("Tutor application pending approval.");
}

session_regenerate_id(true);

$_SESSION["isLoggedIn"] = true;
$_SESSION["user_id"]   = (int)$user["id"];
$_SESSION["full_name"] = (string)$user["full_name"];
$_SESSION["role"]      = (string)$user["role"];

/**
 * Safe return_to handling:
 * - allow only relative frontend files you explicitly permit
 * - block any absolute URL or directory traversal
 */
function is_safe_return_to(string $path): bool
{
    if ($path === "") return false;

    // No schemes/hosts
    if (preg_match('/^[a-zA-Z][a-zA-Z0-9+\-.]*:\/\//', $path)) return false;

    // No traversal
    if (str_contains($path, "..")) return false;

    // Must be a simple frontend file path
    // Allow: courses.html with optional query string
    if (preg_match('/^courses\.php(\?.*)?$/', $path)) return true;

    // (Optional) you can whitelist more later:
    // if (preg_match('/^student_home_profile\.php(\?.*)?$/', $path)) return true;

    return false;
}

if (is_safe_return_to($returnTo)) {
    header("Location: ../frontend/" . $returnTo);
    exit;
}

// Default redirects by role
if ($_SESSION["role"] === "admin") {
    header("Location: ../api/dashboard_admin.php");
} elseif ($_SESSION["role"] === "tutor") {
    header("Location: /studypal/frontend/tutor_home_profile.php");
} elseif ($_SESSION["role"] === "parent") {
    header("Location: ../frontend/parent_home_profile.php");
} else {
    header("Location: ../frontend/student_home_profile.php");
}
exit;