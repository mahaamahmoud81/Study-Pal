<?php
session_start();
require_once "../includes/db_connect.php";
require_once "../includes/functions.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("Invalid request method.");
}

$full_name = trim($_POST["full_name"] ?? "");
$email     = strtolower(trim($_POST["email"] ?? ""));
$password  = $_POST["password"] ?? "";

if (!$full_name || !$email || !$password) {
    die("Please fill out all parent fields.");
}

if (!validate_email($email)) {
    die("Invalid email format.");
}

$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$stmt->execute([$email]);

if ($stmt->fetch()) {
    die("Email already registered.");
}

$password_hash = password_hash($password, PASSWORD_DEFAULT);

$insert = $pdo->prepare("
    INSERT INTO users (full_name, email, password, role, approved)
    VALUES (?, ?, ?, 'parent', 1)
");

$insert->execute([$full_name, $email, $password_hash]);

header("Location: ../frontend/login.html");
exit;
?>
