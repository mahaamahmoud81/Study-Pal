<?php
require_once "../includes/db_connect.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    die("Invalid request.");
}

$fname = trim($_POST["fname"]);
$lname = trim($_POST["lname"]);
$full_name = $fname . " " . $lname;

$email = strtolower(trim($_POST["email"]));
$password = $_POST["password"];
$dob = $_POST["dob"];

$qualification = trim($_POST["qualification"]);
$subject = trim($_POST["subject"]);
$level = trim($_POST["level"]);
$rate = $_POST["rate"];

if (!$fname || !$lname || !$email || !$password || !$dob || !$qualification || !$subject || !$level || !$rate) {
    die("All fields are required.");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Invalid email.");
}

/* Check duplicate email */
$check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
$check->execute([$email]);
if ($check->fetch()) {
    die("Email already registered.");
}

/* Create user */
$password_hash = password_hash($password, PASSWORD_DEFAULT);

$stmt = $pdo->prepare("
    INSERT INTO users (full_name, dob, email, password, role, approved)
    VALUES (?, ?, ?, ?, 'tutor', 0)
");
$stmt->execute([$full_name, $dob, $email, $password_hash]);

$user_id = $pdo->lastInsertId();

/* Create tutor profile */
$stmt = $pdo->prepare("
    INSERT INTO tutor_profiles (user_id, qualification, subject, level, rate)
    VALUES (?, ?, ?, ?, ?)
");
$stmt->execute([$user_id, $qualification, $subject, $level, $rate]);

echo "Tutor application submitted successfully. Await admin approval.";
exit;
