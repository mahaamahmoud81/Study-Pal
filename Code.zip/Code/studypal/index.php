<?php
echo "<h1>StudyPal Backend Running</h1>";
echo "<p>Use Postman or frontend to test API.</p>";
?>
